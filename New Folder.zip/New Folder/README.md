# VantixShop Status
Real-time infrastructure monitoring & status platform. **Brand:** VantixShop · **Developer:** AashirwadGamerzz

## Features
Single-page dark glass UI · background HTTP/TCP monitoring (default 60s) · SQLite storage · 24h/7d/30d/overall uptime from real history · automatic incidents · rate limiting (429) · admin panel (services, servers, incidents, analytics, theme, branding, audit log).

## Installation
```
pip install -r requirements.txt
cp .env.example .env   # edit values
python app.py
```
Open http://127.0.0.1:5000. The SQLite DB (`database/status.db`) and tables are created on first launch.

## Environment variables
`ADMIN_USERNAME`, `ADMIN_PASSWORD` (used only when no admin exists; if unset a random password is printed once to the console), `SECRET_KEY` (auto-generated and stored in DB if unset), `FLASK_ENV` (`production` enables secure cookies — requires HTTPS), `HOST`, `PORT`.

## Admin & monitoring
Sign in via **Admin**. Add services (HTTP/HTTPS URL) and servers (TCP host:port); each is checked at its own interval (10s–24h) with its own timeout. No sample data is seeded — everything shown is real monitoring output. Status: 2xx/3xx online, 4xx or >3s degraded, 5xx/timeout/refused offline.

## Theme & branding
Admin → Theme: presets, colors, glow, radius, blur, fonts, sizes, live preview, save/reset. Admin → Branding: name, logo, favicon, texts. All persisted in SQLite.

## Production
Run a single worker process (the monitor thread lives in `app.py`), behind HTTPS reverse proxy, e.g. `python app.py` under systemd. Multiple gunicorn workers would run duplicate monitors.

## Security notes
Passwords hashed (Werkzeug), HttpOnly SameSite session cookies, CSRF token on admin writes, SQLite-backed per-IP rate limits (public 60/min, login 5/min, admin 120/min), no secrets in code, audit log. Admins can make the server request arbitrary URLs — grant admin access only to trusted people. If behind a proxy, rate limiting keys on the proxy IP unless you add ProxyFix.
