"""VantixShop Status - infrastructure monitoring platform. Developer: AashirwadGamerzz"""
import os, sqlite3, time, json, socket, secrets, threading, urllib.request, urllib.error, urllib.parse
from contextlib import contextmanager
from functools import wraps
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, jsonify, request, session, render_template
from werkzeug.security import generate_password_hash, check_password_hash

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "database", "status.db")
os.makedirs(os.path.dirname(DB), exist_ok=True)


def now():
    return int(time.time())


@contextmanager
def db():
    c = sqlite3.connect(DB, timeout=20)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    try:
        yield c
        c.commit()
    finally:
        c.close()


TARGET_COLS = """id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, location TEXT DEFAULT '',
 url TEXT DEFAULT '', host TEXT DEFAULT '', port INTEGER DEFAULT 0, type TEXT DEFAULT 'http',
 description TEXT DEFAULT '', interval_s INTEGER DEFAULT 60, timeout_s INTEGER DEFAULT 10,
 enabled INTEGER DEFAULT 1, status TEXT DEFAULT 'unknown', latency INTEGER, http_status INTEGER,
 last_check INTEGER, error TEXT, created INTEGER NOT NULL, hide_url INTEGER DEFAULT 0, maintenance INTEGER DEFAULT 0"""
SCHEMA = f"""
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS servers({TARGET_COLS});
CREATE TABLE IF NOT EXISTS services({TARGET_COLS});
CREATE TABLE IF NOT EXISTS monitoring_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, target_type TEXT NOT NULL, target_id INTEGER NOT NULL,
 ts INTEGER NOT NULL, status TEXT NOT NULL, http_status INTEGER, latency INTEGER, error_message TEXT);
CREATE INDEX IF NOT EXISTS idx_logs ON monitoring_logs(target_type, target_id, ts);
CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY AUTOINCREMENT, target_type TEXT NOT NULL, target_id INTEGER NOT NULL,
 name TEXT NOT NULL, kind TEXT NOT NULL, started INTEGER NOT NULL, resolved INTEGER, error TEXT);
CREATE INDEX IF NOT EXISTS idx_inc ON incidents(target_type, target_id, resolved);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS theme_settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS branding_settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS rate_limits(ip TEXT NOT NULL, bucket TEXT NOT NULL, window INTEGER NOT NULL, count INTEGER NOT NULL, PRIMARY KEY(ip, bucket, window));
CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, admin TEXT, detail TEXT, ip TEXT, ts INTEGER NOT NULL);
"""

BRAND_DEFAULT = {
    "name": "VantixShop", "logo": "", "favicon": "", "title": "VantixShop Status",
    "subtitle": "Infrastructure Monitoring", "tagline": "Monitor Everything. Stay Online.",
    "hero_heading": "Server Monitoring Made Simple",
    "hero_description": "Real-time monitoring and uptime tracking for your infrastructure. Get instant status updates and comprehensive system insights from one dashboard.",
    "footer": "© 2026 VantixShop. All rights reserved.", "credit": "Powered by VantixShop Monitoring",
}
THEME_DEFAULT = {
    "primary": "#8b5cf6", "secondary": "#3b82f6", "success": "#22c55e", "danger": "#ef4444", "warning": "#f59e0b",
    "bg": "#050508", "card": "#0e0e18", "border": "#26263a", "text": "#f5f5fa", "muted": "#8b8ba3",
    "glow": 0.5, "radius": 20, "blur": 16, "shadow": 0.5, "grid": 1, "speed": 1, "button": "gradient",
    "font": "Inter, system-ui, -apple-system, Segoe UI, sans-serif", "h1": 3, "body": 15, "width": 1180,
}


def migrate(c):
    for tt in ("servers", "services"):
        cols = {r["name"] for r in c.execute(f"PRAGMA table_info({tt})")}
        for col, ddl in (("hide_url", "INTEGER DEFAULT 0"), ("maintenance", "INTEGER DEFAULT 0")):
            if col not in cols:
                c.execute(f"ALTER TABLE {tt} ADD COLUMN {col} {ddl}")


def init_db():
    with db() as c:
        c.executescript(SCHEMA)
        migrate(c)
        if not c.execute("SELECT 1 FROM settings WHERE key='secret_key'").fetchone():
            c.execute("INSERT INTO settings VALUES('secret_key',?)", (secrets.token_hex(32),))
        user = os.environ.get("ADMIN_USERNAME", "admin")
        if not c.execute("SELECT 1 FROM admins").fetchone():
            pw = os.environ.get("ADMIN_PASSWORD")
            if not pw:
                pw = secrets.token_urlsafe(12)
                print(f"\n[VantixShop] No ADMIN_PASSWORD set. Generated one-time admin login -> {user} / {pw}\n")
            c.execute("INSERT INTO admins(username,password_hash,created) VALUES(?,?,?)", (user, generate_password_hash(pw), now()))


init_db()
app = Flask(__name__)
with db() as _c:
    app.secret_key = os.environ.get("SECRET_KEY") or _c.execute("SELECT value FROM settings WHERE key='secret_key'").fetchone()[0]
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("FLASK_ENV") == "production",
                  PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 30)  # 30 days - admin stays logged in


def site_maintenance_on():
    with db() as c:
        r = c.execute("SELECT value FROM settings WHERE key='site_maintenance'").fetchone()
    return bool(r and json.loads(r["value"]))


EXEMPT_PREFIXES = ("/api/login", "/api/logout", "/api/session", "/api/admin", "/static")


@app.before_request
def keep_alive():
    session.permanent = True


@app.before_request
def maintenance_gate():
    # Only public data endpoints are gated; "/" always loads the SPA shell (so admins can
    # still reach the login screen), and admin/session/login/static routes are always open.
    if session.get("admin") or not request.path.startswith("/api/") or request.path.startswith(EXEMPT_PREFIXES):
        return
    if site_maintenance_on():
        return jsonify(error="Site is under maintenance. Please check back soon.", maintenance=True), 503

# ---------------------------------------------------------------- security
LIMITS = {"public": (60, 60), "login": (5, 60), "admin": (120, 60)}


def limited(bucket):
    lim, win = LIMITS[bucket]
    ip, w = request.remote_addr or "?", now() // win
    with db() as c:
        c.execute("DELETE FROM rate_limits WHERE window<?", (w - 1,))
        c.execute("INSERT INTO rate_limits VALUES(?,?,?,1) ON CONFLICT(ip,bucket,window) DO UPDATE SET count=count+1", (ip, bucket, w))
        n = c.execute("SELECT count FROM rate_limits WHERE ip=? AND bucket=? AND window=?", (ip, bucket, w)).fetchone()[0]
    return n > lim


def err(msg, code=400):
    return jsonify(error=msg), code


def public(f):
    @wraps(f)
    def w(*a, **k):
        if limited("public"):
            return err("Too many requests. Please try again shortly.", 429)
        return f(*a, **k)
    return w


def admin_only(f):
    @wraps(f)
    def w(*a, **k):
        if limited("admin"):
            return err("Too many requests. Please try again shortly.", 429)
        if not session.get("admin"):
            return err("Authentication required", 401)
        if request.method != "GET" and not secrets.compare_digest(request.headers.get("X-CSRF-Token", ""), session.get("csrf", "x")):
            return err("Invalid CSRF token", 403)
        return f(*a, **k)
    return w


def audit(action, detail=""):
    with db() as c:
        c.execute("INSERT INTO audit_logs(action,admin,detail,ip,ts) VALUES(?,?,?,?,?)",
                  (action, session.get("admin"), str(detail)[:300], request.remote_addr, now()))


# ---------------------------------------------------------------- monitoring
def check_http(url, timeout):
    t = time.time()
    p = urllib.parse.urlparse(url or "")
    if p.scheme not in ("http", "https") or not p.netloc:
        return "unknown", None, None, "Invalid URL"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "VantixShop-Status/1.0"})
        try:
            code = urllib.request.urlopen(req, timeout=timeout).status
        except urllib.error.HTTPError as e:
            code = e.code
        ms = int((time.time() - t) * 1000)
        st = "online" if code < 400 else ("degraded" if code < 500 else "offline")
        if st == "online" and ms > 3000:
            st = "degraded"
        return st, code, ms, None if st == "online" else f"HTTP {code}"
    except Exception as e:
        return "offline", None, int((time.time() - t) * 1000), str(e)[:200]


def check_tcp(host, port, timeout):
    t = time.time()
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            pass
        return "online", None, int((time.time() - t) * 1000), None
    except Exception as e:
        return "offline", None, int((time.time() - t) * 1000), str(e)[:200]


def run_check(tt, r):
    if tt == "services":
        return check_http(r["url"], r["timeout_s"])
    return check_tcp(r["host"], r["port"], r["timeout_s"])


def record(c, tt, r, res):
    st, code, ms, e = res
    ts = now()
    c.execute("INSERT INTO monitoring_logs(target_type,target_id,ts,status,http_status,latency,error_message) VALUES(?,?,?,?,?,?,?)",
              (tt, r["id"], ts, st, code, ms, e))
    c.execute(f"UPDATE {tt} SET status=?,latency=?,http_status=?,last_check=?,error=? WHERE id=?", (st, ms, code, ts, e, r["id"]))
    if r["maintenance"]:
        return
    open_inc = c.execute("SELECT id,kind FROM incidents WHERE target_type=? AND target_id=? AND resolved IS NULL", (tt, r["id"])).fetchone()
    if st in ("offline", "degraded"):
        if not open_inc:
            c.execute("INSERT INTO incidents(target_type,target_id,name,kind,started,error) VALUES(?,?,?,?,?,?)", (tt, r["id"], r["name"], st, ts, e))
        elif open_inc["kind"] != st:
            c.execute("UPDATE incidents SET kind=?,error=? WHERE id=?", (st, e, open_inc["id"]))
    elif st == "online" and open_inc:
        c.execute("UPDATE incidents SET resolved=? WHERE id=?", (ts, open_inc["id"]))
    c.execute("DELETE FROM monitoring_logs WHERE ts<?", (ts - 35 * 86400,)) if ts % 50 == 0 else None


inflight, lock = set(), threading.Lock()


def check_one(tt, rid, force=False):
    key = (tt, rid)
    with lock:
        if key in inflight:
            return
        inflight.add(key)
    try:
        with db() as c:
            r = c.execute(f"SELECT * FROM {tt} WHERE id=?", (rid,)).fetchone()
        if r:
            res = run_check(tt, r)
            with db() as c:
                record(c, tt, r, res)
    except Exception as e:  # a failing check must never kill the worker
        print("[monitor]", tt, rid, e)
    finally:
        with lock:
            inflight.discard(key)


def worker():
    pool = ThreadPoolExecutor(max_workers=8)
    while True:
        try:
            with db() as c:
                for tt in ("services", "servers"):
                    for r in c.execute(f"SELECT id FROM {tt} WHERE enabled=1 AND maintenance=0 AND (last_check IS NULL OR last_check+interval_s<=?)", (now(),)):
                        pool.submit(check_one, tt, r["id"])
        except Exception as e:
            print("[monitor loop]", e)
        time.sleep(5)


# ---------------------------------------------------------------- data helpers
def uptime(c, tt, rid, secs=None):
    q, a = "SELECT COUNT(*) n, SUM(status='online') u FROM monitoring_logs WHERE target_type=? AND target_id=?", [tt, rid]
    if secs:
        q += " AND ts>=?"
        a.append(now() - secs)
    r = c.execute(q, a).fetchone()
    return round(100 * (r["u"] or 0) / r["n"], 2) if r["n"] else None


def items(c, tt, is_admin):
    out = []
    for r in c.execute(f"SELECT * FROM {tt} {'' if is_admin else 'WHERE enabled=1'} ORDER BY name"):
        d = dict(r)
        d.update(up24=uptime(c, tt, r["id"], 86400), up7=uptime(c, tt, r["id"], 7 * 86400),
                 up30=uptime(c, tt, r["id"], 30 * 86400), up_all=uptime(c, tt, r["id"]))
        if d["maintenance"]:
            d["status"] = "maintenance"
        if not is_admin:
            if tt == "servers":
                d.pop("host"), d.pop("port")
            if d["hide_url"]:
                d["url"] = ""
                d["location"] = ""
        out.append(d)
    return out


def kv(c, table, default):
    d = dict(default)
    for r in c.execute(f"SELECT key,value FROM {table}"):
        try:
            d[r["key"]] = json.loads(r["value"])
        except ValueError:
            pass
    return d


def snapshot(is_admin=False):
    with db() as c:
        sv, sc = items(c, "servers", is_admin), items(c, "services", is_admin)
        inc = [dict(r) for r in c.execute("SELECT * FROM incidents ORDER BY started DESC LIMIT 25")]
        theme, brand = kv(c, "theme_settings", THEME_DEFAULT), kv(c, "branding_settings", BRAND_DEFAULT)
    act = [x for x in sv + sc if x["enabled"]]
    tot, on = len(act), sum(x["status"] == "online" for x in act)
    off = sum(x["status"] == "offline" for x in act)
    deg = sum(x["status"] == "degraded" for x in act)
    known = [x for x in act if x["status"] not in ("unknown", "maintenance")]
    if not known:
        state = "unknown"
    elif off and off * 2 >= len(known):
        state = "major"
    elif off or deg:
        state = "degraded"
    else:
        state = "operational"
    lat = [x["latency"] for x in known if x["latency"] is not None]
    return {"overview": {
        "servers": len(sv), "servers_online": sum(x["status"] == "online" for x in sv if x["enabled"]),
        "services": len(sc), "services_up": sum(x["status"] == "online" for x in sc if x["enabled"]),
        "availability": round(100 * on / len(known), 1) if known else None, "state": state,
        "avg_latency": round(sum(lat) / len(lat)) if lat else None, "open_incidents": sum(1 for i in inc if not i["resolved"]),
        "failed_services": sum(x["status"] in ("offline", "degraded") for x in sc if x["enabled"]),
        "offline_servers": sum(x["status"] == "offline" for x in sv if x["enabled"]),
    }, "servers": sv, "services": sc, "incidents": inc, "theme": theme, "brand": brand,
        "theme_defaults": THEME_DEFAULT, "updated": now()}


# ---------------------------------------------------------------- validation
FIELDS = {"services": ["name", "url", "type", "location", "description", "interval_s", "timeout_s", "enabled"],
          "servers": ["name", "location", "host", "port", "type", "description", "interval_s", "timeout_s", "enabled"]}


def clean(tt, d):
    def num(k, lo, hi, dv):
        try:
            return max(lo, min(hi, int(d.get(k, dv))))
        except (TypeError, ValueError):
            return dv
    def flag(k, dv=False):
        return 1 if d.get(k, dv) in (True, 1, "1", "true") else 0
    o = {"name": str(d.get("name", "")).strip()[:100], "location": str(d.get("location", ""))[:100],
         "description": str(d.get("description", ""))[:300], "interval_s": num("interval_s", 10, 86400, 60),
         "timeout_s": num("timeout_s", 1, 60, 10), "enabled": flag("enabled", True),
         "hide_url": flag("hide_url", False), "maintenance": flag("maintenance", False)}
    if not o["name"]:
        raise ValueError("Name is required")
    if tt == "services":
        o["url"] = str(d.get("url", "")).strip()
        p = urllib.parse.urlparse(o["url"])
        if p.scheme not in ("http", "https") or not p.netloc:
            raise ValueError("A valid http(s) URL is required")
        o["type"] = str(d.get("type") or "http")[:20]
    else:
        o["host"] = str(d.get("host", "")).strip()[:255]
        if not o["host"]:
            raise ValueError("Host is required")
        o["port"] = num("port", 1, 65535, 0)
        if not o["port"]:
            raise ValueError("A valid port (1-65535) is required")
        o["type"] = "tcp"
    return o


# ---------------------------------------------------------------- routes
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/status")
@public
def api_status():
    return jsonify(snapshot(False))


@app.route("/api/session")
@public
def api_session():
    if session.get("admin") and not session.get("csrf"):
        session["csrf"] = secrets.token_hex(16)
    return jsonify(admin=session.get("admin"), csrf=session.get("csrf"))


@app.route("/api/login", methods=["POST"])
def api_login():
    if limited("login"):
        return err("Too many requests. Please try again shortly.", 429)
    d = request.get_json(silent=True) or {}
    with db() as c:
        r = c.execute("SELECT * FROM admins WHERE username=?", (str(d.get("username", "")),)).fetchone()
    if not r or not check_password_hash(r["password_hash"], str(d.get("password", ""))):
        audit("login_failed", d.get("username", ""))
        return err("Invalid credentials", 401)
    session.clear()
    session.update(admin=r["username"], csrf=secrets.token_hex(16))
    audit("login")
    return jsonify(admin=r["username"], csrf=session["csrf"])


@app.route("/api/logout", methods=["POST"])
@admin_only
def api_logout():
    audit("logout")
    session.clear()
    return jsonify(ok=True)


@app.route("/api/admin/all")
@admin_only
def admin_all():
    return jsonify(snapshot(True))


@app.route("/api/admin/<tt>", methods=["POST"])
@admin_only
def create(tt):
    if tt not in FIELDS:
        return err("Not found", 404)
    try:
        o = clean(tt, request.get_json(silent=True) or {})
    except ValueError as e:
        return err(str(e))
    o["created"] = now()
    with db() as c:
        cur = c.execute(f"INSERT INTO {tt}({','.join(o)}) VALUES({','.join('?' * len(o))})", list(o.values()))
        rid = cur.lastrowid
    audit(f"{tt}_created", o["name"])
    threading.Thread(target=check_one, args=(tt, rid), daemon=True).start()
    return jsonify(id=rid)


@app.route("/api/admin/<tt>/<int:rid>", methods=["PUT", "DELETE"])
@admin_only
def modify(tt, rid):
    if tt not in FIELDS:
        return err("Not found", 404)
    with db() as c:
        if request.method == "DELETE":
            c.execute(f"DELETE FROM {tt} WHERE id=?", (rid,))
            c.execute("DELETE FROM monitoring_logs WHERE target_type=? AND target_id=?", (tt, rid))
            c.execute("DELETE FROM incidents WHERE target_type=? AND target_id=?", (tt, rid))
            audit(f"{tt}_deleted", rid)
            return jsonify(ok=True)
        cur = c.execute(f"SELECT * FROM {tt} WHERE id=?", (rid,)).fetchone()
        if not cur:
            return err("Not found", 404)
        d = request.get_json(silent=True) or {}
        try:
            o = clean(tt, {**dict(cur), **d})
        except ValueError as e:
            return err(str(e))
        c.execute(f"UPDATE {tt} SET {','.join(k + '=?' for k in o)} WHERE id=?", list(o.values()) + [rid])
    audit(f"{tt}_edited", o["name"])
    return jsonify(ok=True)


@app.route("/api/admin/<tt>/<int:rid>/check", methods=["POST"])
@admin_only
def check_now(tt, rid):
    if tt not in FIELDS:
        return err("Not found", 404)
    check_one(tt, rid)
    return jsonify(ok=True)


@app.route("/api/admin/test", methods=["POST"])
@admin_only
def test_conn():
    d = request.get_json(silent=True) or {}
    tt = "services" if d.get("kind") == "services" else "servers"
    try:
        o = clean(tt, d)
    except ValueError as e:
        return err(str(e))
    st, code, ms, e = run_check(tt, o)
    return jsonify(status=st, http_status=code, latency=ms, error=e)


@app.route("/api/admin/<tt>/<int:rid>/history")
@admin_only
def history(tt, rid):
    with db() as c:
        rows = c.execute("SELECT ts,status,http_status,latency,error_message FROM monitoring_logs WHERE target_type=? AND target_id=? ORDER BY ts DESC LIMIT 100", (tt, rid))
        return jsonify([dict(r) for r in rows])


@app.route("/api/admin/incidents/<int:iid>/resolve", methods=["POST"])
@admin_only
def resolve(iid):
    with db() as c:
        c.execute("UPDATE incidents SET resolved=? WHERE id=? AND resolved IS NULL", (now(), iid))
    audit("incident_updated", iid)
    return jsonify(ok=True)


@app.route("/api/admin/analytics")
@admin_only
def analytics():
    since = now() - 86400
    with db() as c:
        s = c.execute("SELECT COUNT(*) n, AVG(latency) a, MAX(latency) mx, MIN(latency) mn, SUM(status!='online') f FROM monitoring_logs WHERE ts>=?", (since,)).fetchone()
        series = [dict(r) for r in c.execute("SELECT (ts/3600)*3600 t, AVG(latency) v FROM monitoring_logs WHERE ts>=? AND latency IS NOT NULL GROUP BY t ORDER BY t", (since,))]
        down = c.execute("SELECT SUM(COALESCE(resolved,?)-started) FROM incidents WHERE started>=?", (now(), since)).fetchone()[0] or 0
        inc = c.execute("SELECT COUNT(*) FROM incidents WHERE started>=?", (since,)).fetchone()[0]
    return jsonify(checks=s["n"], avg=round(s["a"]) if s["a"] else None, max=s["mx"], min=s["mn"], failures=s["f"] or 0,
                   downtime=down, incidents=inc, series=series)


def kv_route(table, default, name):
    @admin_only
    def handler():
        with db() as c:
            if request.method == "GET":
                return jsonify(kv(c, table, default))
            if request.method == "DELETE":
                c.execute(f"DELETE FROM {table}")
            else:
                d = request.get_json(silent=True) or {}
                for k, v in d.items():
                    if k in default and len(json.dumps(v)) < 2000:
                        c.execute(f"INSERT INTO {table} VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, json.dumps(v)))
            out = kv(c, table, default)
        audit(f"{name}_changed")
        return jsonify(out)
    handler.__name__ = name + "_route"
    app.route(f"/api/admin/{name}", methods=["GET", "PUT", "DELETE"])(handler)


kv_route("theme_settings", THEME_DEFAULT, "theme")
kv_route("branding_settings", BRAND_DEFAULT, "branding")


@app.route("/api/admin/site-maintenance", methods=["GET", "PUT"])
@admin_only
def site_maintenance():
    if request.method == "PUT":
        d = request.get_json(silent=True) or {}
        on = bool(d.get("on"))
        with db() as c:
            c.execute("INSERT INTO settings VALUES('site_maintenance',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (json.dumps(on),))
        audit("site_maintenance_changed", on)
    return jsonify(on=site_maintenance_on())


@app.route("/api/admin/audit")
@admin_only
def audit_list():
    with db() as c:
        return jsonify([dict(r) for r in c.execute("SELECT * FROM audit_logs ORDER BY ts DESC LIMIT 100")])


@app.errorhandler(404)
def nf(e):
    return err("Not found", 404) if request.path.startswith("/api/") else render_template("index.html")


@app.errorhandler(Exception)
def boom(e):
    code = getattr(e, "code", 500)
    if code == 500:
        print("[error]", repr(e))
    return err("Something went wrong. Please try again." if code == 500 else getattr(e, "description", "Error"), code if isinstance(code, int) else 500)


if __name__ == "__main__":
    threading.Thread(target=worker, daemon=True).start()
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)), debug=False, use_reloader=False)
