"use strict";
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const S = { data: null, admin: null, csrf: null, tab: "dashboard", live: null };
const LABEL = { operational: "All Systems Operational", degraded: "Some Systems Degraded", major: "Major System Outage", unknown: "Waiting for monitoring data" };
const PRESETS = {
  "Vantix Purple": {},
  "Midnight Blue": { primary: "#3b82f6", secondary: "#06b6d4", bg: "#03060d", card: "#0a1120", border: "#1e2a44" },
  "Cyber Indigo": { primary: "#6366f1", secondary: "#a855f7", bg: "#04040c", card: "#0d0d1f", border: "#2a2a52" },
  "Emerald Cloud": { primary: "#10b981", secondary: "#14b8a6", bg: "#030806", card: "#0a1411", border: "#1c3329" },
  "Solar Amber": { primary: "#f59e0b", secondary: "#fb923c", bg: "#0a0602", card: "#181008", border: "#3a2a12" },
  "Minimal Dark": { primary: "#a1a1aa", secondary: "#71717a", bg: "#0a0a0a", card: "#131313", border: "#262626", glow: 0.1, grid: 0 },
};

async function api(path, method = "GET", body) {
  const o = { method, headers: { "Content-Type": "application/json" } };
  if (method !== "GET") o.headers["X-CSRF-Token"] = S.csrf || "";
  if (body !== undefined) o.body = JSON.stringify(body);
  let r;
  try { r = await fetch(path, o); } catch { toast("Network error. Please check your connection."); throw new Error("net"); }
  let j = {}; try { j = await r.json(); } catch { }
  if (r.status === 503 && j.maintenance) { const e = new Error("maintenance"); e.maintenance = true; throw e; }
  if (r.status === 429) { toast("Too many requests. Please try again shortly."); throw new Error("429"); }
  if (r.status === 401 && S.admin) { S.admin = null; location.hash = "#admin"; }
  if (!r.ok) { toast(j.error || "Request failed"); throw new Error(j.error || r.status); }
  return j;
}
let tt;
function toast(m) { const t = $("#toast"); t.textContent = m; t.classList.add("show"); clearTimeout(tt); tt = setTimeout(() => t.classList.remove("show"), 3500); }

// ---------- theme & brand
function applyTheme(t) {
  const r = document.documentElement.style, m = { primary: 1, secondary: 1, success: 1, danger: 1, warning: 1, bg: 1, card: 1, border: 1, text: 1, muted: 1, glow: 1, shadow: 1, speed: 1 };
  for (const k in m) if (t[k] !== undefined) r.setProperty("--" + k, t[k]);
  r.setProperty("--radius", t.radius + "px"); r.setProperty("--blur", t.blur + "px"); r.setProperty("--font", t.font);
  r.setProperty("--h1", t.h1 + "rem"); r.setProperty("--body", t.body + "px"); r.setProperty("--width", t.width + "px"); r.setProperty("--gridA", t.grid ? 1 : 0);
  document.body.dataset.btn = t.button;
}
function applyBrand(b) {
  document.title = b.title; $("#brandName").textContent = b.name;
  $("#logo").innerHTML = b.logo ? `<img src="${esc(b.logo)}" alt="" onerror="this.parentNode.textContent='${esc(b.name[0] || "V")}'">` : esc((b.name || "V")[0]);
  if (b.favicon) $("#favicon").href = b.favicon;
  $("#ftText").textContent = b.footer; $("#ftCredit").textContent = b.credit;
}

// ---------- helpers
const ago = t => { if (!t) return "Never"; const s = Math.max(0, Math.floor(Date.now() / 1000 - t)); return s < 60 ? s + "s ago" : s < 3600 ? Math.floor(s / 60) + "m ago" : s < 86400 ? Math.floor(s / 3600) + "h ago" : Math.floor(s / 86400) + "d ago"; };
const dur = s => s < 60 ? s + "s" : s < 3600 ? Math.floor(s / 60) + "m" : Math.floor(s / 3600) + "h " + Math.floor(s % 3600 / 60) + "m";
const pct = v => v == null ? "—" : v + "%";
const badge = s => `<span class="badge s-${s}"><i class="dot"></i>${s}</span>`;
const skeleton = n => `<div class="grid">${"<div class='sk'></div>".repeat(n)}</div>`;
function targetCard(x, isSvc) {
  const hidden = x.hide_url;
  const line = hidden ? "🔒 Hidden" : (isSvc ? esc(x.url) : esc(x.location || "—"));
  return `<article class="card"><div class="t"><div><b>${esc(x.name)}</b><div class="url">${line}</div></div>${badge(x.status)}</div>
  <div class="kv"><div><span>Latency</span>${x.latency != null ? x.latency + "ms" : "—"}</div><div><span>Uptime (24h)</span>${pct(x.up24)}</div>
  ${isSvc ? `<div><span>HTTP status</span>${x.http_status ?? "—"}</div><div><span>Location</span>${esc(x.location || "—")}</div>` : `<div><span>Uptime (30d)</span>${pct(x.up30)}</div><div><span>Response time</span>${x.latency != null ? x.latency + "ms" : "—"}</div>`}
  <div><span>Last checked</span>${ago(x.last_check)}</div><div><span>Uptime (7d)</span>${pct(x.up7)}</div></div>
  <div class="bar"><i style="width:${x.up24 ?? 0}%"></i></div></article>`;
}
const list = (a, isSvc, what) => a.length ? `<div class="grid">${a.map(x => targetCard(x, isSvc)).join("")}</div>` : `<div class="card empty">No ${what} configured yet. An administrator can add them from the Admin panel.</div>`;
const incTable = a => a.length ? `<div class="card scroll"><table><tr><th>ID</th><th>Target</th><th>Type</th><th>Started</th><th>Duration</th><th>Status</th><th>Error</th></tr>${a.map(i => `<tr><td>#${i.id}</td><td>${esc(i.name)}</td><td>${badge(i.kind)}</td><td>${new Date(i.started * 1000).toLocaleString()}</td><td>${dur((i.resolved || Math.floor(Date.now() / 1000)) - i.started)}</td><td>${i.resolved ? "Resolved" : "Ongoing"}</td><td>${esc(i.error || "")}</td></tr>`).join("")}</table></div>` : `<div class="card empty">No incidents recorded. 🎉</div>`;

// ---------- public views
const V = {};
V.overview = d => {
  const o = d.overview, b = d.brand;
  return `<section class="hero"><div class="tag">${esc(b.tagline)}</div><div class="pill s-${o.state}"><i class="dot"></i>${LABEL[o.state]}</div>
  <h1>${esc(b.hero_heading)}</h1><p>${esc(b.hero_description)}</p>
  <div class="btns"><a class="btn p" href="#services">View Status</a><a class="btn" href="#admin">Admin Login</a></div></section>
  <div class="grid stats">${[["Servers", o.servers], ["Online", o.servers_online], ["Services", o.services], ["Healthy", o.services_up], ["Availability", pct(o.availability)], ["Avg latency", o.avg_latency != null ? o.avg_latency + "ms" : "—"]]
      .map(([k, v]) => `<div class="card stat"><small>${k}</small><b>${v}</b></div>`).join("")}</div>
  <h2>🖥 Recent Servers</h2>${list(d.servers.slice(0, 6), false, "servers")}
  <h2>🌐 Recent Services</h2>${list(d.services.slice(0, 6), true, "services")}
  <h2>⚠ Recent Incidents</h2>${incTable(d.incidents.slice(0, 5))}`;
};
V.servers = d => `<h2>🖥 Servers (${d.overview.servers_online}/${d.overview.servers} online)</h2>${list(d.servers, false, "servers")}`;
V.services = d => `<h2>🌐 Services (${d.overview.services_up}/${d.overview.services} up)</h2>${list(d.services, true, "services")}`;
V.incidents = d => `<h2>⚠ Incidents</h2>${incTable(d.incidents)}`;
V.analytics = () => (S.admin ? `<div id="adm"></div>` : "");

function maintenanceScreen() {
  const name = $("#brandName").textContent || "VantixShop";
  return `<div class="hero"><div class="pill s-maintenance"><i class="dot"></i>Under Maintenance</div>
  <h1 style="font-size:2rem">${esc(name)} is temporarily unavailable</h1>
  <p>We're performing scheduled maintenance to keep things running smoothly. Please check back shortly.</p>
  <div class="btns"><a class="btn p" href="#" id="retry">Refresh</a><a class="btn" href="#admin">Admin Login</a></div></div>`;
}
document.addEventListener("click", e => { if (e.target && e.target.id === "retry") { e.preventDefault(); refresh(); } });

// ---------- router
function route() {
  const [r, sub] = (location.hash.slice(1) || "overview").split("/");
  document.querySelectorAll("nav a").forEach(a => a.classList.toggle("on", a.dataset.r === r));
  $("#nav").classList.remove("open");
  const v = $("#view"); v.style.animation = "none"; void v.offsetWidth; v.style.animation = "";
  if (["admin", "analytics", "settings"].includes(r)) {
    if (!S.admin) return renderLogin();
    S.tab = r === "analytics" ? "analytics" : r === "settings" ? "theme" : (sub || "dashboard");
    return renderAdmin();
  }
  if (!V[r]) return (location.hash = "#overview");
  if (S.siteMaintenance) { v.innerHTML = maintenanceScreen(); return; }
  if (!S.data) { v.innerHTML = skeleton(6); return; }
  v.innerHTML = V[r](S.data);
}
async function refresh() {
  try {
    const d = await api("/api/status");
    S.siteMaintenance = false; S.data = d; applyTheme(d.theme); applyBrand(d.brand);
    $("#ftState").textContent = LABEL[d.overview.state]; $("#ftTime").textContent = new Date(d.updated * 1000).toLocaleTimeString();
    const r = (location.hash.slice(1) || "overview").split("/")[0];
    if (V[r] && r !== "analytics" && !document.querySelector("dialog[open]")) route();
  } catch (e) {
    if (e.maintenance) { S.siteMaintenance = true; $("#ftState").textContent = "Maintenance"; route(); }
  }
}

// ---------- admin
function renderLogin() {
  $("#view").innerHTML = `<div class="card" style="max-width:420px;margin:40px auto"><h2 style="margin-top:0">🔐 Admin Login</h2>
  <label for="u">Username</label><input id="u" autocomplete="username"><label for="p">Password</label><input id="p" type="password" autocomplete="current-password">
  <div class="btns" style="margin-top:20px"><button class="btn p" id="go">Sign in</button></div></div>`;
  const go = async () => {
    try {
      const j = await api("/api/login", "POST", { username: $("#u").value, password: $("#p").value });
      S.admin = j.admin; S.csrf = j.csrf; toast("Welcome back"); location.hash = "#admin"; route();
    } catch { }
  };
  $("#go").onclick = go; $("#p").onkeydown = e => e.key === "Enter" && go();
}
const TABS = ["dashboard", "services", "servers", "incidents", "analytics", "theme", "branding", "security"];
async function renderAdmin() {
  const v = $("#view");
  v.innerHTML = `<div class="tabs" role="tablist">${TABS.map(t => `<a href="#admin/${t}" class="${S.tab === t ? "on" : ""}">${t[0].toUpperCase() + t.slice(1)}</a>`).join("")}<a href="#" id="lo">Logout</a></div><div id="adm">${skeleton(3)}</div>`;
  $("#lo").onclick = async e => { e.preventDefault(); try { await api("/api/logout", "POST"); } catch { } S.admin = null; S.csrf = null; location.hash = "#overview"; };
  try {
    const a = await api("/api/admin/all"); S.adm = a;
    await A[S.tab](a, $("#adm"));
  } catch { }
}
const A = {};
A.dashboard = (a, el) => {
  const o = a.overview, all = [...a.servers, ...a.services].filter(x => x.enabled), up = all.map(x => x.up_all).filter(x => x != null);
  const cells = [["Total servers", o.servers], ["Online servers", o.servers_online], ["Offline servers", o.offline_servers], ["Total services", o.services], ["Healthy services", o.services_up], ["Failed services", o.failed_services], ["Current incidents", o.open_incidents], ["Avg latency", o.avg_latency != null ? o.avg_latency + "ms" : "—"], ["Overall uptime", up.length ? (up.reduce((x, y) => x + y, 0) / up.length).toFixed(2) + "%" : "—"]];
  el.innerHTML = `<div class="grid stats">${cells.map(([k, v]) => `<div class="card stat"><small>${k}</small><b>${v}</b></div>`).join("")}</div>`;
};
const F = {
  services: [["name", "Name"], ["url", "URL", "url"], ["type", "Type", "select", ["http", "https", "api"]], ["location", "Location"], ["interval_s", "Monitoring interval (s)", "number"], ["timeout_s", "Timeout (s)", "number"]],
  servers: [["name", "Server name"], ["location", "Location"], ["host", "Host"], ["port", "Port", "number"], ["description", "Description"], ["interval_s", "Monitoring interval (s)", "number"], ["timeout_s", "Timeout (s)", "number"]],
};
function form(tt, x = {}) {
  const m = $("#modal");
  m.innerHTML = `<h2 style="margin-top:0">${x.id ? "Edit" : "Add"} ${tt === "services" ? "service" : "server"}</h2><div class="form">${F[tt].map(([k, l, t, o]) => `<div><label for="f_${k}">${l}</label>${t === "select" ? `<select id="f_${k}">${o.map(z => `<option ${x[k] === z ? "selected" : ""}>${z}</option>`).join("")}</select>` : `<input id="f_${k}" type="${t || "text"}" value="${esc(x[k] ?? (k === "interval_s" ? 60 : k === "timeout_s" ? 10 : ""))}">`}</div>`).join("")}</div>
  <label><input type="checkbox" id="f_enabled" ${x.enabled === 0 ? "" : "checked"}> Enabled</label>
  <label><input type="checkbox" id="f_hide_url" ${x.hide_url ? "checked" : ""}> Hide ${tt === "services" ? "URL" : "location"} from public view</label>
  <label><input type="checkbox" id="f_maintenance" ${x.maintenance ? "checked" : ""}> Under maintenance (shown as "Maintenance" publicly, checks paused)</label>
  <div id="tres" class="mut"></div>
  <div class="btns" style="margin-top:18px;justify-content:flex-end"><button class="btn" id="cn">Cancel</button><button class="btn" id="tc">Test Connection</button><button class="btn p" id="sv">Save</button></div>`;
  const body = () => { const o = { enabled: $("#f_enabled").checked, hide_url: $("#f_hide_url").checked, maintenance: $("#f_maintenance").checked }; F[tt].forEach(([k]) => o[k] = $("#f_" + k).value); return o; };
  m.showModal();
  $("#cn").onclick = () => m.close();
  $("#tc").onclick = async () => { $("#tres").textContent = "Testing…"; try { const r = await api("/api/admin/test", "POST", { ...body(), kind: tt }); $("#tres").textContent = `Result: ${r.status}${r.http_status ? " (HTTP " + r.http_status + ")" : ""}${r.latency != null ? " · " + r.latency + "ms" : ""}${r.error ? " · " + r.error : ""}`; } catch { $("#tres").textContent = ""; } };
  $("#sv").onclick = async () => { try { await api(x.id ? `/api/admin/${tt}/${x.id}` : `/api/admin/${tt}`, x.id ? "PUT" : "POST", body()); m.close(); toast("Saved"); renderAdmin(); } catch { } };
}
function targetAdmin(tt) {
  return (a, el) => {
    const rows = a[tt];
    el.innerHTML = `<div class="btns" style="justify-content:flex-start;margin-bottom:16px"><button class="btn p" id="add">+ Add ${tt === "services" ? "service" : "server"}</button></div>
    <div class="card scroll"><table><tr><th>Name</th><th>${tt === "services" ? "URL" : "Host"}</th><th>Status</th><th>Latency</th><th>Uptime</th><th>Last check</th><th>Actions</th></tr>
    ${rows.map(x => `<tr><td>${esc(x.name)}${x.hide_url ? ' <span class="mut" title="Hidden from public">🔒</span>' : ""}</td><td class="url">${esc(tt === "services" ? x.url : x.host + ":" + x.port)}</td><td>${!x.enabled ? badge("unknown") : x.maintenance ? badge("maintenance") : badge(x.status)}</td><td>${x.latency ?? "—"}${x.latency != null ? "ms" : ""}</td><td>${pct(x.up_all)}</td><td>${ago(x.last_check)}</td>
    <td class="acts"><button class="btn sm" data-a="edit" data-id="${x.id}">Edit</button><button class="btn sm" data-a="toggle" data-id="${x.id}">${x.enabled ? "Pause" : "Resume"}</button><button class="btn sm" data-a="maint" data-id="${x.id}">${x.maintenance ? "End Maintenance" : "Maintenance"}</button><button class="btn sm" data-a="check" data-id="${x.id}">Check Now</button><button class="btn sm" data-a="hist" data-id="${x.id}">History</button><button class="btn sm d" data-a="del" data-id="${x.id}">Delete</button></td></tr>`).join("") || `<tr><td colspan="7" class="empty">Nothing here yet.</td></tr>`}</table></div>`;
    $("#add").onclick = () => form(tt);
    el.querySelectorAll("[data-a]").forEach(b => b.onclick = async () => {
      const id = +b.dataset.id, x = rows.find(r => r.id === id);
      try {
        if (b.dataset.a === "edit") return form(tt, x);
        if (b.dataset.a === "toggle") await api(`/api/admin/${tt}/${id}`, "PUT", { enabled: x.enabled ? 0 : 1 });
        if (b.dataset.a === "maint") await api(`/api/admin/${tt}/${id}`, "PUT", { maintenance: x.maintenance ? 0 : 1 });
        if (b.dataset.a === "check") { b.textContent = "…"; await api(`/api/admin/${tt}/${id}/check`, "POST"); }
        if (b.dataset.a === "del") { if (!confirm(`Delete ${x.name}?`)) return; await api(`/api/admin/${tt}/${id}`, "DELETE"); }
        if (b.dataset.a === "hist") { const h = await api(`/api/admin/${tt}/${id}/history`); const m = $("#modal"); m.innerHTML = `<h2 style="margin-top:0">History: ${esc(x.name)}</h2><div class="scroll"><table><tr><th>Time</th><th>Status</th><th>HTTP</th><th>ms</th><th>Error</th></tr>${h.map(r => `<tr><td>${new Date(r.ts * 1000).toLocaleString()}</td><td>${badge(r.status)}</td><td>${r.http_status ?? ""}</td><td>${r.latency ?? ""}</td><td>${esc(r.error_message || "")}</td></tr>`).join("") || "<tr><td colspan=5>No checks yet</td></tr>"}</table></div><div class="btns" style="margin-top:16px"><button class="btn" onclick="this.closest('dialog').close()">Close</button></div>`; return m.showModal(); }
        renderAdmin();
      } catch { }
    });
  };
}
A.services = targetAdmin("services"); A.servers = targetAdmin("servers");
A.incidents = (a, el) => {
  el.innerHTML = incTable(a.incidents); el.querySelectorAll("tr").forEach((tr, i) => {
    const inc = a.incidents[i - 1]; if (inc && !inc.resolved) { const b = document.createElement("button"); b.className = "btn sm"; b.textContent = "Resolve"; b.onclick = async () => { try { await api(`/api/admin/incidents/${inc.id}/resolve`, "POST"); renderAdmin(); } catch { } }; tr.lastElementChild.appendChild(b); }
  });
};
A.analytics = async (a, el) => {
  const r = await api("/api/admin/analytics"), max = Math.max(1, ...r.series.map(s => s.v));
  el.innerHTML = `<div class="grid stats">${[["Avg latency", r.avg != null ? r.avg + "ms" : "—"], ["Highest", r.max != null ? r.max + "ms" : "—"], ["Lowest", r.min != null ? r.min + "ms" : "—"], ["Checks (24h)", r.checks], ["Failures", r.failures], ["Incidents", r.incidents], ["Downtime", dur(r.downtime)]].map(([k, v]) => `<div class="card stat"><small>${k}</small><b>${v}</b></div>`).join("")}</div>
  <h2>📈 Average latency per hour (24h)</h2><div class="card">${r.series.length ? `<svg class="chart" viewBox="0 0 ${r.series.length * 20} 100" preserveAspectRatio="none" role="img" aria-label="Latency chart">${r.series.map((s, i) => `<rect x="${i * 20 + 3}" width="14" y="${100 - s.v / max * 96}" height="${s.v / max * 96}" rx="3"><title>${new Date(s.t * 1000).getHours()}:00 – ${Math.round(s.v)}ms</title></rect>`).join("")}</svg>` : `<div class="empty">Not enough data yet.</div>`}</div>`;
};
const TF = [["primary", "Primary", "color"], ["secondary", "Secondary", "color"], ["success", "Success", "color"], ["danger", "Danger", "color"], ["warning", "Warning", "color"], ["bg", "Background", "color"], ["card", "Card background", "color"], ["border", "Card border", "color"], ["text", "Text", "color"], ["muted", "Muted text", "color"],
["glow", "Glow intensity", "range", 0, 1, .05], ["radius", "Border radius", "range", 0, 36, 1], ["blur", "Card blur", "range", 0, 40, 1], ["shadow", "Shadow intensity", "range", 0, 1, .05], ["speed", "Animation speed (s multiplier)", "range", .2, 3, .1], ["h1", "Heading size (rem)", "range", 1.5, 5, .1], ["body", "Body size (px)", "range", 12, 20, 1], ["width", "Container width (px)", "range", 800, 1600, 20]];
A.theme = async (a, el) => {
  let t = await api("/api/admin/theme"); const saved = { ...t };
  el.innerHTML = `<div class="card"><label>Preset</label><select id="pre"><option value="">Choose a preset…</option>${Object.keys(PRESETS).map(p => `<option>${p}</option>`).join("")}</select>
  <div class="form">${TF.map(([k, l, ty, mn, mx, st]) => `<div><label for="t_${k}">${l}</label><input id="t_${k}" type="${ty}" ${mn !== undefined ? `min="${mn}" max="${mx}" step="${st}"` : ""}></div>`).join("")}
  <div><label for="t_grid">Grid background</label><select id="t_grid"><option value="1">On</option><option value="0">Off</option></select></div>
  <div><label for="t_button">Button style</label><select id="t_button"><option>gradient</option><option>solid</option><option>outline</option></select></div>
  <div><label for="t_font">Font family</label><input id="t_font"></div></div>
  <div class="btns" style="justify-content:flex-start;margin-top:20px"><button class="btn p" id="ts">Save Theme</button><button class="btn" id="tr">Reset Theme</button></div><p class="mut" style="margin-top:12px">Changes preview live; press Save to persist them.</p></div>`;
  const fill = () => { [...TF.map(x => x[0]), "grid", "button", "font"].forEach(k => $("#t_" + k).value = t[k]); };
  const read = () => { [...TF.map(x => x[0]), "grid", "button", "font"].forEach(k => { const v = $("#t_" + k).value; t[k] = ["button", "font"].includes(k) || TF.find(x => x[0] === k && x[2] === "color") ? v : +v; }); applyTheme(t); };
  fill(); el.querySelectorAll("input,select").forEach(i => i.oninput = () => i.id !== "pre" && read());
  $("#pre").onchange = e => { if (!e.target.value) return; t = { ...S.data.theme_defaults, ...PRESETS[e.target.value] }; fill(); applyTheme(t); };
  $("#ts").onclick = async () => { try { S.data.theme = await api("/api/admin/theme", "PUT", t); toast("Theme saved"); } catch { } };
  $("#tr").onclick = async () => { try { t = await api("/api/admin/theme", "DELETE"); fill(); applyTheme(t); toast("Theme reset"); } catch { } };
};
const BF = [["name", "Brand name"], ["logo", "Logo URL"], ["favicon", "Favicon URL"], ["title", "Browser title"], ["subtitle", "Subtitle"], ["tagline", "Tagline"], ["hero_heading", "Hero heading"], ["hero_description", "Hero description"], ["footer", "Footer text"], ["credit", "Developer credit"]];
A.branding = async (a, el) => {
  const b = await api("/api/admin/branding");
  el.innerHTML = `<div class="card"><div class="form">${BF.map(([k, l]) => `<div><label for="b_${k}">${l}</label><input id="b_${k}" value="${esc(b[k])}"></div>`).join("")}</div>
  <div class="btns" style="justify-content:flex-start;margin-top:20px"><button class="btn p" id="bs">Save Branding</button><button class="btn" id="br">Reset</button></div></div>`;
  const read = () => { BF.forEach(([k]) => b[k] = $("#b_" + k).value); applyBrand(b); };
  el.querySelectorAll("input").forEach(i => i.oninput = read);
  $("#bs").onclick = async () => { try { S.data.brand = await api("/api/admin/branding", "PUT", b); toast("Branding saved"); } catch { } };
  $("#br").onclick = async () => { try { await api("/api/admin/branding", "DELETE"); renderAdmin(); refresh(); } catch { } };
};
A.security = async (a, el) => {
  const [r, sm] = await Promise.all([api("/api/admin/audit"), api("/api/admin/site-maintenance")]);
  el.innerHTML = `<div class="card" style="margin-bottom:20px"><div class="t"><div><b>🚧 Site-wide maintenance mode</b><div class="mut">When on, public visitors see a maintenance screen and can't reach status data. Admins can still sign in and manage everything.</div></div>${badge(sm.on ? "offline" : "online")}</div>
  <div class="btns" style="justify-content:flex-start"><button class="btn ${sm.on ? "" : "p"}" id="smt">${sm.on ? "Turn Off Maintenance Mode" : "Turn On Maintenance Mode"}</button></div></div>
  <h2 style="margin-top:0">🛡 Audit log</h2><div class="card scroll"><table><tr><th>Action</th><th>Admin</th><th>Detail</th><th>IP</th><th>Time</th></tr>${r.map(x => `<tr><td>${esc(x.action)}</td><td>${esc(x.admin || "—")}</td><td>${esc(x.detail || "")}</td><td>${esc(x.ip || "")}</td><td>${new Date(x.ts * 1000).toLocaleString()}</td></tr>`).join("")}</table></div>`;
  $("#smt").onclick = async () => { try { await api("/api/admin/site-maintenance", "PUT", { on: !sm.on }); toast(sm.on ? "Maintenance mode off" : "Maintenance mode on"); renderAdmin(); refresh(); } catch { } };
};

// ---------- init
$("#burger").onclick = () => { const n = $("#nav"); $("#burger").setAttribute("aria-expanded", n.classList.toggle("open")); };
addEventListener("hashchange", route);
(async () => {
  route();
  try { const s = await api("/api/session"); S.admin = s.admin; S.csrf = s.csrf; } catch { }
  await refresh(); route();
  S.live = setInterval(refresh, 15000);
})();
