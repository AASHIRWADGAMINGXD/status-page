# VantixShop Status

A real-time infrastructure monitoring and status platform.

**Brand:** VantixShop
**Developer:** AashirwadGamerzz

## Features

- Single-page public status site (Overview, Servers, Services, Incidents) with live polling — no page reloads
- Background monitoring worker that actually pings your servers/services on a per-target interval, with isolated failure handling (one bad target can't crash the worker or the app)
- Real uptime math (24h / 7d / 30d / all-time) computed from stored history — nothing is faked
- Automatic incident creation on failure/degradation and automatic resolution when a target recovers
- Full admin dashboard: manage servers & services (add/edit/pause/delete/check now), view incidents, per-target analytics with sparklines
- Live theme customization (colors, glow, radius, blur, shadow, animation speed, font, button style, container width) with instant preview and SQLite persistence, plus 6 built-in presets
- Full branding customization (name, logo, favicon, titles, hero copy, footer, developer credit)
- Hashed admin passwords, secure sessions, CSRF-protected admin writes, rate limiting (login/admin/public), audit log of admin actions
- SQLite database created automatically on first run — no external services required

## Technology

- Backend: Python 3, Flask, SQLite (stdlib `sqlite3`), a lightweight background thread pool for monitoring
- Frontend: a single Jinja template shell + vanilla JavaScript SPA (`static/js/app.js`) using `fetch()` polling every 15s
- No Node build step, no frontend framework, no paid services, no MongoDB/Firebase

## Requirements

- Python 3.9+
- `pip install -r requirements.txt` (just Flask)

## Installation

```bash
cd vantixshop-status
python3 -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt
cp .env.example .env
# edit .env and set ADMIN_USERNAME, ADMIN_PASSWORD, SECRET_KEY
python app.py
```

Then open **http://127.0.0.1:5000**.

If you don't set `ADMIN_PASSWORD`, the app auto-generates one on first launch and prints it once to the console — copy it immediately, it is not stored anywhere else in plain text.

## Environment variables

| Variable | Purpose |
|---|---|
| `ADMIN_USERNAME` | Admin login username (default `admin`) |
| `ADMIN_PASSWORD` | Admin login password. Hashed into the database on first run / on change. |
| `SECRET_KEY` | Flask session signing key. Generate with `python -c "import secrets;print(secrets.token_hex(32))"`. If unset, a random key is generated each restart, which will log everyone out. |
| `FLASK_ENV` | Set to `production` to mark session cookies `Secure` (requires HTTPS). |
| `PORT` / `HOST` | Bind address/port (defaults `127.0.0.1:5000`). |

Never commit your real `.env` file — only `.env.example` is tracked.

## Database

SQLite database is created automatically at `database/status.db` on first launch, with all tables (`admins`, `servers`, `services`, `monitoring_logs`, `incidents`, `settings`, `theme_settings`, `branding_settings`, `rate_limits`, `audit_logs`) and indexes. No manual migration step is needed. Delete the `.db` file to reset the app to a clean state (you'll be prompted for a fresh admin password/generated one on next launch).

## Running locally

```bash
python app.py
```

The monitoring worker starts automatically in a background thread and checks each enabled server/service once its configured interval has elapsed (default 60s), storing every check to `monitoring_logs` and updating uptime/incidents.

## Production deployment

- Run behind a production WSGI server, e.g. `gunicorn -w 2 -b 0.0.0.0:8000 app:app` (the Flask dev server used by `python app.py` prints its own warning and should not be used in production).
- Put it behind a reverse proxy (nginx/Caddy) with TLS, and set `FLASK_ENV=production` so session cookies are marked `Secure`.
- Set a permanent, random `SECRET_KEY` in the environment so sessions survive restarts.
- Back up `database/status.db` periodically.

## Admin access

Visit the site and click **Admin** in the header (or **Admin Login** on the hero), sign in with your configured credentials. From the admin dashboard you can manage servers, services, incidents, theme, branding, and view the audit log — all via the same single-page interface.

## Monitoring configuration

Each server or service has its own `interval_s` (how often it's checked) and `timeout_s` (request timeout). HTTP targets are marked degraded on slow responses (>3s) or 4xx codes, and offline on 5xx/connection failures; TCP server checks confirm the port is reachable. Use **Check Now** in the admin panel to force an immediate check, and **Test Connection** in the add/edit form to test before saving.

## Theme customization

Settings → Theme Customization lets an admin change every visual token (colors, glow, radius, blur, shadow, animation speed, font, button style, heading/body size, container width) with an instant live preview, plus 6 built-in presets to start from. Changes are saved to SQLite and applied for every visitor immediately.

## Security notes

- Passwords are hashed with Werkzeug's `generate_password_hash` (never stored in plain text).
- Sessions are Flask's signed, HTTP-only, `SameSite=Lax` cookies.
- All admin-mutating requests require a per-session CSRF token issued at login.
- Rate limits are enforced server-side per IP (60/min public, 5/min login, 120/min admin) and return HTTP 429 with a clean message — they cannot be bypassed with query parameters.
- Stack traces are never sent to the browser; unexpected errors return a generic message and are logged server-side only.
- All target URLs/hosts are validated before use, and monitoring failures on one target are isolated so they can't crash the worker or the app.
