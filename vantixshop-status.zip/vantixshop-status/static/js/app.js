/* VantixShop Status - frontend SPA. Developer: AashirwadGamerzz */
(() => {
'use strict';
const $ = (s, e = document) => e.querySelector(s);
const el = (t, a = {}, kids = []) => { const n = document.createElement(t); for (const k in a) { if (k === 'html') n.innerHTML = a[k]; else if (k.startsWith('on')) n.addEventListener(k.slice(2), a[k]); else n.setAttribute(k, a[k]); } for (const c of [].concat(kids)) if (c != null) n.append(c); return n; };
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtTime = ts => ts ? new Date(ts * 1000).toLocaleString() : '—';
const fmtPct = v => v == null ? '—' : v.toFixed(2) + '%';
const fmtMs = v => v == null ? '—' : v + 'ms';
const LABEL = { online: 'Online', offline: 'Offline', degraded: 'Degraded', maintenance: 'Maintenance', unknown: 'Unknown' };

const state = { data: null, admin: false, csrf: '', route: 'overview', theme: {}, brand: {}, loading: true, error: null };
const FIELDS = ['primary', 'secondary', 'success', 'danger', 'warning', 'bg', 'card', 'border', 'text', 'muted'];

function toast(msg, bad) {
  const t = $('#toast'); t.textContent = msg; t.className = bad ? 'show bad' : 'show';
  clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), 3200);
}

async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (state.csrf) headers['X-CSRF-Token'] = state.csrf;
  const r = await fetch(path, { ...opts, headers });
  let body = null; try { body = await r.json(); } catch { /* no body */ }
  if (!r.ok) throw new Error((body && body.error) || `Request failed (${r.status})`);
  return body;
}

function applyTheme(theme, brand) {
  const root = document.body.style;
  for (const [k, v] of Object.entries(theme || {})) {
    if (['glow', 'shadow', 'anim'].includes(k)) root.setProperty(`--${k}`, v);
    else if (k === 'radius' || k === 'blur') root.setProperty(`--${k}`, v + 'px');
    else if (k === 'h_size') root.setProperty('--fs-h', v + 'px');
    else if (k === 'b_size') root.setProperty('--fs-b', v + 'px');
    else if (k === 'width') root.setProperty('--w', v + 'px');
    else if (k === 'font') document.body.style.setProperty('--font', { grotesk: '"Space Grotesk","Inter",system-ui,sans-serif', inter: '"Inter",system-ui,sans-serif', mono: '"JetBrains Mono","Courier New",monospace', serif: '"Georgia","Times New Roman",serif' }[v] || null);
    else if (k === 'card_alpha') root.setProperty('--card-alpha', v + '%');
    else if (k === 'bg_overlay') root.setProperty('--bg-overlay', v);
    else if (k === 'bg_image') root.setProperty('--bg-image', v ? `url("${v.replace(/"/g, '%22')}")` : 'none');
    else if (FIELDS.includes(k)) root.setProperty(`--${k}`, v);
  }
  document.body.dataset.grid = theme?.grid ?? 1;
  document.body.dataset.btn = theme?.button || 'gradient';
  if (brand?.title) document.title = brand.title;
  const fav = $('#favicon'); if (fav && brand?.favicon) fav.href = brand.favicon;
}

function renderHeader() {
  const b = state.brand;
  const links = [['overview', 'Status'], ['services', 'Services'], ['servers', 'Servers'], ['incidents', 'Incidents']];
  const hdr = $('#hdr');
  hdr.innerHTML = '';
  const nav = el('nav', { id: 'nav' }, links.map(([r, l]) => el('a', { href: `#${r}`, class: state.route === r ? 'on' : '', onclick: e => { e.preventDefault(); nav.classList.remove('open'); go(r); } }, l)));
  nav.append(state.admin
    ? el('a', { href: '#admin', class: state.route.startsWith('admin') ? 'on' : '', onclick: e => { e.preventDefault(); go('admin'); } }, 'Admin Dashboard')
    : el('a', { href: '#admin-login', class: state.route === 'admin-login' ? 'on' : '', onclick: e => { e.preventDefault(); go('admin-login'); } }, 'Admin'));
  hdr.append(el('div', { class: 'wrap' }, [
    el('a', { href: '#overview', class: 'brand', onclick: e => { e.preventDefault(); go('overview'); } }, [
      b.logo ? el('img', { src: b.logo, alt: '' }) : el('span', { class: 'logo' }, (b.name || 'V')[0]),
      el('span', {}, [el('b', {}, b.name || 'VantixShop'), el('small', {}, b.subtitle || 'Status')])
    ]),
    el('button', { class: 'btn burger', 'aria-label': 'Menu', onclick: () => nav.classList.toggle('open') }, '☰'),
    nav
  ]));
}

function renderFooter() {
  const d = state.data;
  $('#ftr').innerHTML = '';
  $('#ftr').append(
    el('div', {}, state.brand.footer || '© 2026 VantixShop. All rights reserved.'),
    el('div', {}, state.brand.credit || 'Powered by VantixShop Monitoring'),
    el('div', { class: 'pill', style: 'margin-top:10px' }, d ? `Last updated: ${fmtTime(d.summary.last_updated)}` : '')
  );
}

function statusBanner(overall) {
  const map = { operational: ['All Systems Operational', 'operational'], degraded: ['Some Systems Degraded', 'degraded'], major: ['Major System Outage', 'major'], unknown: ['Awaiting First Check', 'unknown'] };
  const [label, cls] = map[overall] || map.unknown;
  return el('div', { class: `banner ${cls}` }, [el('span', { class: 'dot' }), label]);
}

function statCard(value, label, cls) {
  return el('div', { class: 'card stat' }, [el('b', { class: cls || '' }, String(value)), el('span', {}, label)]);
}

function targetCard(kind, t, opts = {}) {
  const st = t.status || 'unknown';
  const kids = [el('div', { class: 'row' }, [el('span', { class: `dot` }), el('h3', {}, t.name)])];
  kids.push(el('div', { class: 'sub' }, kind === 'service' ? t.url : (t.location || '')));
  const kv = [['Status', LABEL[st] || st, `t-${st}`], ['Latency', fmtMs(t.latency)]];
  if (kind === 'service') kv.push(['HTTP', t.http_status ?? '—']);
  kv.push(['Uptime (24h)', fmtPct(t.uptime?.h24)], ['Uptime (30d)', fmtPct(t.uptime?.d30)], ['Last checked', t.last_check ? new Date(t.last_check * 1000).toLocaleTimeString() : '—']);
  kids.push(el('div', { class: 'kv' }, kv.map(([k, v, c]) => el('div', {}, [el('small', {}, k), el('b', { class: c || '' }, String(v))]))));
  kids.push(el('div', { class: 'bar' }, el('span', { style: `width:${t.uptime?.d30 ?? 0}%` })));
  if (opts.admin) {
    kids.push(el('div', { class: 'acts', style: 'margin-top:12px' }, [
      el('button', { class: 'btn sm', onclick: () => opts.onCheck(t.id) }, 'Check now'),
      el('button', { class: 'btn sm', onclick: () => opts.onToggle(t.id, !t.enabled) }, t.enabled ? 'Pause' : 'Resume'),
      el('button', { class: 'btn sm', onclick: () => opts.onEdit(t.id) }, 'Edit'),
      el('button', { class: 'btn sm dng', onclick: () => opts.onDelete(t.id) }, 'Delete')
    ]));
  }
  return el('div', { class: `card tgt s-${st}` }, kids);
}

function screenLoading() { return el('div', { class: 'wrap grid g3' }, [el('div', { class: 'card sk' }), el('div', { class: 'card sk' }), el('div', { class: 'card sk' })]); }

function screenOverview() {
  const d = state.data, s = d.summary;
  const frag = el('div', {});
  frag.append(el('section', { class: 'hero wrap' }, [
    statusBanner(s.overall),
    el('h1', {}, state.brand.hero_heading || 'Server Monitoring Made Simple'),
    el('p', {}, state.brand.hero_desc || ''),
    el('a', { href: '#services', class: 'btn pri', onclick: e => { e.preventDefault(); go('services'); } }, 'View Status'),
    el('a', { href: '#admin-login', class: 'btn', onclick: e => { e.preventDefault(); go(state.admin ? 'admin' : 'admin-login'); } }, 'Admin Login')
  ]));
  frag.append(el('div', { class: 'wrap grid g4' }, [
    statCard(s.servers, 'Servers'), statCard(s.servers_online, 'Online', 'ok'),
    statCard(s.services, 'Services'), statCard(s.services_healthy, 'Healthy', 'ok')
  ]));
  frag.append(el('h2', { class: 'sec wrap' }, '📊 System Overview'));
  frag.append(el('p', { class: 'subt wrap' }, 'Current infrastructure status and health metrics'));
  frag.append(el('div', { class: 'wrap grid g4' }, [
    statCard(`${s.servers_online}/${s.servers}`, 'Servers Online'),
    statCard(`${s.services_healthy}/${s.services}`, 'Services Up'),
    statCard(s.overall === 'operational' ? 'Good' : s.overall === 'unknown' ? 'Check' : 'Alert', 'System Health', s.overall === 'operational' ? 'ok' : s.overall === 'unknown' ? 'warn' : 'bad'),
    statCard(s.availability == null ? '—' : s.availability + '%', 'Availability')
  ]));
  frag.append(el('h2', { class: 'sec wrap' }, '🖥️ Recent Servers'));
  frag.append(el('p', { class: 'subt wrap' }, 'Your monitored infrastructure nodes'));
  frag.append(el('div', { class: 'wrap grid g3' }, d.servers.length ? d.servers.slice(0, 6).map(t => targetCard('server', t)) : el('div', { class: 'empty' }, 'No servers added yet.')));
  frag.append(el('h2', { class: 'sec wrap' }, '📡 Recent Services'));
  frag.append(el('p', { class: 'subt wrap' }, 'Monitored uptime services and endpoints'));
  frag.append(el('div', { class: 'wrap grid g3' }, d.services.length ? d.services.slice(0, 6).map(t => targetCard('service', t)) : el('div', { class: 'empty' }, 'No services added yet.')));
  return frag;
}

function screenList(kind) {
  const d = state.data, items = kind === 'server' ? d.servers : d.services;
  const frag = el('div', { class: 'wrap' });
  frag.append(el('h2', { class: 'sec', style: 'margin-top:0' }, kind === 'server' ? '🖥️ Servers' : '📡 Services'), el('span', { class: 'pill' }, `${items.length} total`));
  frag.append(el('div', { class: 'grid g3', style: 'margin-top:16px' }, items.length ? items.map(t => targetCard(kind, t)) : el('div', { class: 'empty' }, `No ${kind}s configured yet.`)));
  return frag;
}

function screenIncidents() {
  const d = state.data;
  const frag = el('div', { class: 'wrap' });
  frag.append(el('h2', { class: 'sec', style: 'margin-top:0' }, '⚠️ Incidents'));
  if (!d.incidents.length) { frag.append(el('div', { class: 'empty' }, 'No incidents recorded. All clear.')); return frag; }
  frag.append(el('div', { class: 'tw' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['ID', 'Target', 'Severity', 'Status', 'Started', 'Duration', 'Resolved'].map(h => el('th', {}, h)))),
    el('tbody', {}, d.incidents.map(i => {
      const dur = Math.max(0, (i.resolved || Math.floor(Date.now() / 1000)) - i.started);
      const durStr = dur > 3600 ? `${(dur / 3600).toFixed(1)}h` : `${Math.round(dur / 60)}m`;
      return el('tr', {}, [
        el('td', {}, '#' + i.id), el('td', {}, i.name || '—'), el('td', { class: `t-${i.severity}` }, LABEL[i.severity] || i.severity),
        el('td', {}, i.status === 'open' ? '🔴 Open' : '🟢 Resolved'), el('td', {}, fmtTime(i.started)), el('td', {}, durStr), el('td', {}, i.resolved ? fmtTime(i.resolved) : '—')
      ]);
    }))
  ])));
  return frag;
}

async function screenAdminLogin() {
  const frag = el('div', { class: 'wrap login' });
  const err = el('div', { class: 'err' });
  const user = el('input', { placeholder: 'Username', autocomplete: 'username' });
  const pass = el('input', { type: 'password', placeholder: 'Password', autocomplete: 'current-password' });
  const submit = async e => {
    e.preventDefault(); err.textContent = '';
    try {
      const r = await api('/api/login', { method: 'POST', body: JSON.stringify({ username: user.value, password: pass.value }) });
      state.admin = true; state.csrf = r.csrf; toast('Welcome back.'); await load(); go('admin');
    } catch (ex) { err.textContent = ex.message; }
  };
  frag.append(el('div', { class: 'card' }, [
    el('h2', { style: 'margin-bottom:6px' }, 'Admin Login'),
    el('p', { class: 'subt' }, 'Sign in to manage VantixShop Status.'),
    el('form', { class: 'form', onsubmit: submit }, [
      el('div', {}, [el('label', {}, 'Username'), user]), el('div', {}, [el('label', {}, 'Password'), pass]),
      el('button', { class: 'btn pri', type: 'submit' }, 'Log in')
    ]), err
  ]));
  return frag;
}

/* ---------- Admin dashboard ---------- */
function adminNav(active) {
  const tabs = ['dashboard', 'servers', 'services', 'incidents', 'analytics', 'theme', 'branding', 'security'];
  return el('div', { class: 'tabs' }, tabs.map(t => el('button', { class: 'btn sm' + (active === t ? ' on' : ''), onclick: () => go('admin-' + t) }, t[0].toUpperCase() + t.slice(1))));
}

function adminHeaderRow(sub) {
  return el('div', { class: 'row', style: 'justify-content:space-between;margin-bottom:14px' }, [
    el('h2', { style: 'margin:0' }, '⚙️ Admin — ' + sub),
    el('button', { class: 'btn sm dng', onclick: doLogout }, 'Logout')
  ]);
}

async function doLogout() { try { await api('/api/logout', { method: 'POST' }); } catch { /* ignore */ } state.admin = false; state.csrf = ''; toast('Logged out.'); await load(); go('overview'); }

function screenAdminDashboard() {
  const d = state.data, s = d.summary;
  const frag = el('div', { class: 'wrap' });
  frag.append(adminHeaderRow('Dashboard'), adminNav('dashboard'));
  frag.append(el('div', { class: 'grid g4' }, [
    statCard(s.servers, 'Total Servers'), statCard(s.servers_online, 'Online Servers', 'ok'), statCard(s.servers - s.servers_online, 'Offline Servers', 'bad'),
    statCard(s.services, 'Total Services'), statCard(s.services_healthy, 'Healthy Services', 'ok'), statCard(s.services - s.services_healthy, 'Failed Services', 'bad'),
    statCard(s.open_incidents, 'Current Incidents', s.open_incidents ? 'warn' : 'ok'), statCard(s.avg_latency == null ? '—' : s.avg_latency + 'ms', 'Average Latency'),
    statCard(s.availability == null ? '—' : s.availability + '%', 'Overall Uptime')
  ]));
  return frag;
}

function fieldRow(label, node) { return el('div', {}, [el('label', {}, label), node]); }

function targetForm(kind, existing, onSaved) {
  const v = existing || {};
  const name = el('input', { value: v.name || '', placeholder: 'e.g. Bot Node-1' });
  const location = el('input', { value: v.location || '', placeholder: 'e.g. India' });
  const interval = el('input', { type: 'number', min: 15, value: v.interval_s || 60 });
  const timeout = el('input', { type: 'number', min: 1, value: v.timeout_s || 10 });
  const enabled = el('input', { type: 'checkbox' }); enabled.checked = v.enabled == null ? true : !!v.enabled;
  const err = el('div', { class: 'err' });
  let urlOrHost, extra = [];
  if (kind === 'service') {
    urlOrHost = el('input', { value: v.url || '', placeholder: 'https://example.com' });
  } else {
    urlOrHost = el('input', { value: v.host || '', placeholder: 'Host or full URL' });
    const type = el('select', {}, [el('option', { value: 'tcp' }, 'TCP port check'), el('option', { value: 'http' }, 'HTTP check')]);
    type.value = v.type || 'tcp';
    const port = el('input', { type: 'number', value: v.port || 80 });
    extra = [fieldRow('Monitoring type', type), fieldRow('Port', port)];
    urlOrHost._type = type; urlOrHost._port = port;
  }
  const testBtn = el('button', { class: 'btn sm', type: 'button' }, 'Test Connection');
  testBtn.onclick = async () => {
    testBtn.textContent = 'Testing…';
    try {
      const url = kind === 'service' ? urlOrHost.value : (urlOrHost._type.value === 'http' ? urlOrHost.value : null);
      if (!url) { toast('Test Connection works for HTTP targets.'); return; }
      const r = await api('/api/admin/test', { method: 'POST', body: JSON.stringify({ url, timeout_s: Number(timeout.value) || 10 }) });
      toast(`${LABEL[r.status]} — ${r.http_status ?? ''} ${r.latency ?? ''}${r.latency ? 'ms' : ''} ${r.error || ''}`.trim(), r.status !== 'online');
    } catch (ex) { toast(ex.message, true); } finally { testBtn.textContent = 'Test Connection'; }
  };
  const save = async () => {
    err.textContent = '';
    const payload = { name: name.value, location: location.value, interval_s: Number(interval.value), timeout_s: Number(timeout.value), enabled: enabled.checked };
    if (kind === 'service') payload.url = urlOrHost.value;
    else { payload.host = urlOrHost.value; payload.type = urlOrHost._type.value; payload.port = Number(urlOrHost._port.value); }
    try {
      if (v.id) await api(`/api/admin/${kind}s/${v.id}`, { method: 'PUT', body: JSON.stringify(payload) });
      else await api(`/api/admin/${kind}s`, { method: 'POST', body: JSON.stringify(payload) });
      toast('Saved.'); onSaved();
    } catch (ex) { err.textContent = ex.message; }
  };
  return el('div', { class: 'card', style: 'margin-bottom:20px' }, [
    el('h3', { style: 'margin-bottom:12px' }, v.id ? `Edit ${kind}` : `Add ${kind}`),
    el('div', { class: 'form' }, [fieldRow('Name', name), fieldRow(kind === 'service' ? 'URL' : 'Host', urlOrHost), ...extra,
      fieldRow('Monitoring interval (s)', interval), fieldRow('Timeout (s)', timeout),
      el('div', { style: 'display:flex;align-items:center;gap:8px;margin-top:22px' }, [enabled, el('label', { style: 'margin:0' }, 'Enabled')])]),
    err,
    el('div', { class: 'acts' }, [el('button', { class: 'btn pri', onclick: save }, 'Save'), testBtn, el('button', { class: 'btn', onclick: onSaved }, 'Cancel')])
  ]);
}

function adminTable(kind, items, onChanged) {
  const showForm = { id: null };
  const wrap = el('div', {});
  const rerender = () => { wrap.innerHTML = ''; wrap.append(build()); };
  function build() {
    const f = el('div', {});
    f.append(el('div', { class: 'row', style: 'justify-content:space-between;margin-bottom:14px' }, [
      el('h3', { style: 'margin:0' }, kind === 'service' ? 'Recent Services' : 'Recent Servers'),
      el('button', { class: 'btn pri sm', onclick: () => { showForm.id = 'new'; rerender(); } }, `+ Add ${kind}`)
    ]));
    if (showForm.id) {
      const editing = showForm.id === 'new' ? null : items.find(i => i.id === showForm.id);
      f.append(targetForm(kind, editing, () => { showForm.id = null; onChanged(); }));
    }
    f.append(el('div', { class: 'tw' }, el('table', {}, [
      el('thead', {}, el('tr', {}, ['Name', kind === 'service' ? 'URL' : 'Host', 'Status', 'Latency', 'Uptime', 'Last Check', 'Actions'].map(h => el('th', {}, h)))),
      el('tbody', {}, items.length ? items.map(t => el('tr', {}, [
        el('td', {}, t.name), el('td', {}, kind === 'service' ? t.url : t.host),
        el('td', { class: `t-${t.status}` }, LABEL[t.status] || t.status), el('td', {}, fmtMs(t.latency)), el('td', {}, fmtPct(t.uptime?.d30)),
        el('td', {}, t.last_check ? new Date(t.last_check * 1000).toLocaleTimeString() : '—'),
        el('td', {}, el('div', { class: 'acts' }, [
          el('button', { class: 'btn sm', onclick: () => { showForm.id = t.id; rerender(); } }, 'Edit'),
          el('button', { class: 'btn sm', onclick: async () => { try { await api(`/api/admin/${kind}s/${t.id}/check`, { method: 'POST' }); toast('Check triggered.'); onChanged(); } catch (e) { toast(e.message, true); } } }, 'Check Now'),
          el('button', { class: 'btn sm', onclick: async () => { try { await api(`/api/admin/${kind}s/${t.id}`, { method: 'PUT', body: JSON.stringify({ ...t, enabled: !t.enabled }) }); onChanged(); } catch (e) { toast(e.message, true); } } }, t.enabled ? 'Pause' : 'Resume'),
          el('button', { class: 'btn sm dng', onclick: async () => { if (!confirm(`Delete ${t.name}?`)) return; try { await api(`/api/admin/${kind}s/${t.id}`, { method: 'DELETE' }); toast('Deleted.'); onChanged(); } catch (e) { toast(e.message, true); } } }, 'Delete')
        ]))
      ])) : [el('tr', {}, el('td', { colspan: 7, class: 'empty' }, `No ${kind}s yet.`))])
    ])));
    return f;
  }
  wrap.append(build());
  return wrap;
}

function screenAdminTargets(kind) {
  const d = state.data;
  const frag = el('div', { class: 'wrap' });
  frag.append(adminHeaderRow(kind === 'server' ? 'Servers' : 'Services'), adminNav(kind === 'server' ? 'servers' : 'services'));
  frag.append(adminTable(kind, kind === 'server' ? d.servers : d.services, refresh));
  return frag;
}

function screenAdminIncidents() {
  const d = state.data;
  const frag = el('div', { class: 'wrap' });
  frag.append(adminHeaderRow('Incidents'), adminNav('incidents'));
  if (!d.incidents.length) { frag.append(el('div', { class: 'empty' }, 'No incidents recorded.')); return frag; }
  frag.append(el('div', { class: 'tw' }, el('table', {}, [
    el('thead', {}, el('tr', {}, ['ID', 'Target', 'Severity', 'Status', 'Started', 'Error', 'Resolved', ''].map(h => el('th', {}, h)))),
    el('tbody', {}, d.incidents.map(i => el('tr', {}, [
      el('td', {}, '#' + i.id), el('td', {}, i.name || '—'), el('td', { class: `t-${i.severity}` }, LABEL[i.severity] || i.severity),
      el('td', {}, i.status), el('td', {}, fmtTime(i.started)), el('td', {}, i.error || '—'), el('td', {}, i.resolved ? fmtTime(i.resolved) : '—'),
      el('td', {}, i.status === 'open' ? el('button', { class: 'btn sm', onclick: async () => { try { await api(`/api/admin/incidents/${i.id}/resolve`, { method: 'POST' }); toast('Marked resolved.'); refresh(); } catch (e) { toast(e.message, true); } } }, 'Resolve') : '')
    ])))
  ])));
  return frag;
}

function sparkline(points) {
  if (!points.length) return el('div', { class: 'sub' }, 'No data yet.');
  const w = 280, h = 40, max = Math.max(...points, 1), min = Math.min(...points, 0);
  const pts = points.map((p, i) => `${(i / Math.max(points.length - 1, 1)) * w},${h - ((p - min) / Math.max(max - min, 1)) * h}`).join(' ');
  return el('svg', { class: 'spark', viewBox: `0 0 ${w} ${h}`, html: `<polyline points="${pts}" fill="none" stroke="var(--primary)" stroke-width="2"/>` });
}

async function screenAdminAnalytics() {
  const frag = el('div', { class: 'wrap' });
  frag.append(adminHeaderRow('Analytics'), adminNav('analytics'));
  const body = el('div', { class: 'grid g3' }, el('div', { class: 'card sk' }));
  frag.append(body);
  try {
    const r = await api('/api/admin/analytics');
    body.innerHTML = '';
    if (!r.items.length) { body.append(el('div', { class: 'empty' }, 'No monitoring data yet.')); return frag; }
    r.items.forEach(it => body.append(el('div', { class: 'card' }, [
      el('h3', {}, it.name), el('div', { class: 'sub' }, `${it.type} · last 24h`),
      el('div', { class: 'kv' }, [['Checks', it.checks], ['Avg latency', fmtMs(it.avg)], ['Min', fmtMs(it.min)], ['Max', fmtMs(it.max)], ['Failures', it.fails], ['Downtime', Math.round(it.downtime_s / 60) + 'm']].map(([k, v]) => el('div', {}, [el('small', {}, k), el('b', {}, String(v))]))),
      el('div', { style: 'margin-top:10px' }, sparkline(it.points))
    ])));
  } catch (e) { body.innerHTML = ''; body.append(el('div', { class: 'empty' }, e.message)); }
  return frag;
}

const PRESETS = {
  'Vantix Purple': { primary: '#6366f1', secondary: '#3b82f6' },
  'Midnight Blue': { primary: '#2563eb', secondary: '#0ea5e9' },
  'Cyber Indigo': { primary: '#7c3aed', secondary: '#6366f1' },
  'Emerald Cloud': { primary: '#10b981', secondary: '#22c55e' },
  'Crimson Dark': { primary: '#dc2626', secondary: '#f97316' },
  'Minimal Dark': { primary: '#a3a3a3', secondary: '#737373' }
};

function screenAdminTheme() {
  const frag = el('div', { class: 'wrap' });
  frag.append(adminHeaderRow('Theme Customization'), adminNav('theme'));
  const t = { ...state.theme };
  const colorFields = ['primary', 'secondary', 'success', 'danger', 'warning', 'bg', 'card', 'border', 'text', 'muted'].map(k =>
    fieldRow(k[0].toUpperCase() + k.slice(1) + ' Color', el('input', { type: 'color', value: t[k] || '#000000', oninput: e => { t[k] = e.target.value; preview(); } })));
  const range = (k, lo, hi, label, step) => fieldRow(label, el('input', { type: 'range', min: lo, max: hi, step: step || 1, value: t[k], oninput: e => { t[k] = Number(e.target.value); preview(); } }));
  const select = (k, opts, label) => { const s = el('select', { onchange: e => { t[k] = e.target.value; preview(); } }, opts.map(o => el('option', { value: o }, o))); s.value = t[k]; return fieldRow(label, s); };
  const text = (k, label, placeholder) => fieldRow(label, el('input', { value: t[k] || '', placeholder: placeholder || '', oninput: e => { t[k] = e.target.value; preview(); } }));
  function preview() { applyTheme(t, state.brand); }
  const err = el('div', { class: 'err' });
  const presetSel = el('select', {}, [el('option', { value: '' }, 'Choose a preset…'), ...Object.keys(PRESETS).map(p => el('option', { value: p }, p))]);
  presetSel.onchange = () => { if (presetSel.value) { Object.assign(t, PRESETS[presetSel.value]); rerenderColors(); preview(); } };
  const colorsWrap = el('div', { class: 'form' }, colorFields);
  function rerenderColors() { colorsWrap.innerHTML = ''; colorsWrap.append(...['primary', 'secondary', 'success', 'danger', 'warning', 'bg', 'card', 'border', 'text', 'muted'].map(k => fieldRow(k[0].toUpperCase() + k.slice(1) + ' Color', el('input', { type: 'color', value: t[k] || '#000000', oninput: e => { t[k] = e.target.value; preview(); } })))); }
  frag.append(el('div', { class: 'card' }, [
    el('h3', {}, '🎨 Preset Themes'), el('div', { class: 'form', style: 'grid-template-columns:1fr' }, [presetSel])
  ]));
  frag.append(el('div', { class: 'card', style: 'margin-top:16px' }, [el('h3', {}, 'Colors'), colorsWrap]));
  frag.append(el('div', { class: 'card', style: 'margin-top:16px' }, [
    el('h3', {}, 'Effects & Layout'),
    el('div', { class: 'form' }, [
      range('glow', 0, 2, 'Glow Intensity', .1), range('radius', 0, 40, 'Border Radius'), range('blur', 0, 40, 'Card Blur'),
      range('shadow', 0, 2, 'Shadow Intensity', .1), range('anim', 0.2, 3, 'Animation Speed', .1),
      select('grid', ['1', '0'], 'Grid Background'), select('button', ['gradient', 'solid', 'outline'], 'Button Style'),
      select('font', ['grotesk', 'inter', 'mono', 'serif'], 'Font Family'), range('h_size', 28, 72, 'Heading Size'),
      range('b_size', 13, 20, 'Body Size'), range('width', 900, 1600, 'Container Width')
    ])
  ]));
  frag.append(el('div', { class: 'card', style: 'margin-top:16px' }, [
    el('h3', {}, '🖼️ Custom Background'),
    el('p', { class: 'subt' }, 'Set a background photo for the whole site. Glass cards will sit on top of it — use the overlay slider to keep text readable.'),
    el('div', { class: 'form' }, [
      text('bg_image', 'Background Image URL', 'https://example.com/photo.jpg'),
      range('bg_overlay', 0, 1, 'Background Overlay', .05),
      range('card_alpha', 30, 100, 'Card Glass Opacity')
    ]),
    el('div', { class: 'acts', style: 'margin-top:10px' }, el('button', { class: 'btn sm', onclick: () => { t.bg_image = ''; preview(); } }, 'Remove Background Image'))
  ]));
  frag.append(err);
  frag.append(el('div', { class: 'acts', style: 'margin-top:16px' }, [
    el('button', { class: 'btn pri', onclick: async () => { err.textContent = ''; try { await api('/api/admin/theme', { method: 'PUT', body: JSON.stringify(t) }); state.theme = t; toast('Theme saved.'); } catch (e) { err.textContent = e.message; } } }, 'Save Theme'),
    el('button', { class: 'btn', onclick: async () => { if (!confirm('Reset theme to defaults?')) return; await api('/api/admin/theme/reset', { method: 'POST' }); await load(); toast('Theme reset.'); go('admin-theme'); } }, 'Reset Theme')
  ]));
  return frag;
}

function screenAdminBranding() {
  const frag = el('div', { class: 'wrap' });
  frag.append(adminHeaderRow('Branding'), adminNav('branding'));
  const b = { ...state.brand };
  const err = el('div', { class: 'err' });
  const fields = [['name', 'Brand Name'], ['logo', 'Logo URL'], ['favicon', 'Favicon URL'], ['title', 'Browser Title'], ['subtitle', 'Subtitle'],
    ['hero_heading', 'Hero Heading'], ['hero_desc', 'Hero Description'], ['footer', 'Footer Text'], ['credit', 'Developer Credit']];
  const inputs = fields.map(([k, label]) => fieldRow(label, el('input', { value: b[k] || '', oninput: e => { b[k] = e.target.value; applyTheme(state.theme, b); } })));
  frag.append(el('div', { class: 'card' }, [el('h3', {}, 'Branding'), el('div', { class: 'form' }, inputs), err,
    el('div', { class: 'acts', style: 'margin-top:14px' }, el('button', {
      class: 'btn pri', onclick: async () => { err.textContent = ''; try { await api('/api/admin/branding', { method: 'PUT', body: JSON.stringify(b) }); state.brand = b; toast('Branding saved.'); renderHeader(); renderFooter(); } catch (e) { err.textContent = e.message; } }
    }, 'Save Branding'))]));
  return frag;
}

async function screenAdminSecurity() {
  const frag = el('div', { class: 'wrap' });
  frag.append(adminHeaderRow('Security & Audit Log'), adminNav('security'));
  frag.append(el('div', { class: 'card' }, [
    el('h3', {}, 'Session'), el('p', { class: 'subt' }, 'Sessions use secure, HTTP-only cookies with hashed passwords and CSRF-protected write requests.'),
    el('button', { class: 'btn dng', onclick: doLogout }, 'Log out')
  ]));
  const body = el('div', { class: 'tw', style: 'margin-top:16px' }, el('div', { class: 'card sk' }));
  frag.append(body);
  try {
    const r = await api('/api/admin/audit');
    body.innerHTML = '';
    body.append(el('table', {}, [el('thead', {}, el('tr', {}, ['Action', 'Admin', 'IP', 'Detail', 'Timestamp'].map(h => el('th', {}, h)))),
      el('tbody', {}, r.logs.map(l => el('tr', {}, [el('td', {}, l.action), el('td', {}, l.admin), el('td', {}, l.ip), el('td', {}, l.detail || ''), el('td', {}, fmtTime(l.ts))])))]));
  } catch (e) { body.innerHTML = ''; body.append(el('div', { class: 'empty' }, e.message)); }
  return frag;
}

async function render() {
  const app = $('#app');
  if (state.loading) { app.innerHTML = ''; app.append(screenLoading()); return; }
  if (state.error) { app.innerHTML = ''; app.append(el('div', { class: 'wrap empty' }, state.error)); return; }
  app.innerHTML = '';
  const r = state.route;
  if (r.startsWith('admin') && !state.admin) return go('admin-login');
  try {
    let node;
    if (r === 'overview') node = screenOverview();
    else if (r === 'services') node = screenList('service');
    else if (r === 'servers') node = screenList('server');
    else if (r === 'incidents') node = screenIncidents();
    else if (r === 'admin-login') node = await screenAdminLogin();
    else if (r === 'admin' || r === 'admin-dashboard') node = screenAdminDashboard();
    else if (r === 'admin-servers') node = screenAdminTargets('server');
    else if (r === 'admin-services') node = screenAdminTargets('service');
    else if (r === 'admin-incidents') node = screenAdminIncidents();
    else if (r === 'admin-analytics') node = await screenAdminAnalytics();
    else if (r === 'admin-theme') node = screenAdminTheme();
    else if (r === 'admin-branding') node = screenAdminBranding();
    else if (r === 'admin-security') node = await screenAdminSecurity();
    else node = screenOverview();
    app.append(node);
  } catch (e) {
    console.error('[VantixShop] render failed for route', r, e);
    app.append(el('div', { class: 'wrap' }, el('div', { class: 'card empty' }, [
      el('div', { style: 'font-size:1.1rem;color:var(--text);margin-bottom:8px' }, '⚠ This page failed to load.'),
      el('div', {}, esc(e.message || 'Unknown error')),
      el('button', { class: 'btn', style: 'margin-top:14px', onclick: () => go('overview') }, 'Back to Status')
    ])));
  }
  renderHeader(); renderFooter();
}

function go(route) { state.route = route; if (location.hash.slice(1) !== route) history.pushState({}, '', '#' + route); render(); window.scrollTo(0, 0); }

async function refresh() { await load(); render(); }

async function load() {
  try {
    const sess = await api('/api/session'); state.admin = sess.admin; state.csrf = sess.csrf;
    const d = await api('/api/status');
    state.data = d; state.theme = d.theme; state.brand = d.branding; state.error = null;
    applyTheme(state.theme, state.brand);
  } catch (e) { state.error = e.message || 'Failed to load status data.'; }
  state.loading = false;
}

async function boot() {
  window.addEventListener('popstate', () => { state.route = location.hash.slice(1) || 'overview'; render(); });
  state.route = location.hash.slice(1) || 'overview';
  await load(); render();
  setInterval(async () => { const prevRoute = state.route; try { await load(); } catch { /* keep old data */ } if (state.route === prevRoute) render(); }, 15000);
}
boot();
})();
