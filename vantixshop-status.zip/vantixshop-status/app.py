"""VantixShop Status - infrastructure monitoring. Developer: AashirwadGamerzz. Run: python app.py"""
import os, sqlite3, time, json, threading, secrets, socket, re
import urllib.request, urllib.error
from urllib.parse import urlparse
from functools import wraps
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, jsonify, request, session, render_template
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'database', 'status.db')
os.makedirs(os.path.dirname(DB), exist_ok=True)
if os.path.exists(os.path.join(BASE, '.env')):  # minimal .env loader
    for ln in open(os.path.join(BASE, '.env'), encoding='utf-8'):
        if '=' in ln and not ln.strip().startswith('#'):
            k, v = ln.strip().split('=', 1); os.environ.setdefault(k, v)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or secrets.token_hex(32)  # set SECRET_KEY to keep sessions across restarts
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
                  SESSION_COOKIE_SECURE=os.environ.get('FLASK_ENV') == 'production')
SLOW_MS = 3000

# ---------- database ----------
def db():
    c = sqlite3.connect(DB, timeout=10); c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON'); return c

def run(sql, a=(), f=None):
    c = db()
    try:
        cur = c.execute(sql, a)
        r = cur.fetchone() if f == 'one' else cur.fetchall() if f == 'all' else cur.lastrowid
        c.commit(); return r
    finally: c.close()

COMMON = """name TEXT NOT NULL, location TEXT DEFAULT '', interval_s INTEGER DEFAULT 60, timeout_s INTEGER DEFAULT 10,
 enabled INTEGER DEFAULT 1, status TEXT DEFAULT 'unknown', latency INTEGER, http_status INTEGER, last_check INTEGER,
 last_error TEXT, created INTEGER DEFAULT (strftime('%s','now'))"""
SCHEMA = f"""
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created INTEGER DEFAULT (strftime('%s','now')));
CREATE TABLE IF NOT EXISTS servers(id INTEGER PRIMARY KEY, {COMMON}, host TEXT NOT NULL, port INTEGER DEFAULT 80, type TEXT DEFAULT 'tcp', description TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS services(id INTEGER PRIMARY KEY, {COMMON}, url TEXT NOT NULL, type TEXT DEFAULT 'http');
CREATE TABLE IF NOT EXISTS monitoring_logs(id INTEGER PRIMARY KEY, target_type TEXT NOT NULL, target_id INTEGER NOT NULL, ts INTEGER NOT NULL, status TEXT NOT NULL, http_status INTEGER, latency INTEGER, error_message TEXT);
CREATE INDEX IF NOT EXISTS ix_logs ON monitoring_logs(target_type, target_id, ts);
CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY, target_type TEXT NOT NULL, target_id INTEGER NOT NULL, name TEXT, severity TEXT, status TEXT DEFAULT 'open', started INTEGER, detected INTEGER, resolved INTEGER, error TEXT);
CREATE INDEX IF NOT EXISTS ix_inc ON incidents(target_type, target_id, status);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS theme_settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS branding_settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS rate_limits(ip TEXT, bucket TEXT, window INTEGER, count INTEGER DEFAULT 0, PRIMARY KEY(ip, bucket, window));
CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY, action TEXT, admin TEXT, ip TEXT, detail TEXT, ts INTEGER DEFAULT (strftime('%s','now')));
"""

def init_db():
    c = db(); c.executescript(SCHEMA); c.commit(); c.close()
    u = os.environ.get('ADMIN_USERNAME', 'admin'); p = os.environ.get('ADMIN_PASSWORD')
    row = run('SELECT * FROM admins WHERE username=?', (u,), 'one')
    if not row:
        if not p:
            p = secrets.token_urlsafe(12)
            print(f'\n[VantixShop] ADMIN_PASSWORD not set. Generated one-time password for "{u}": {p}\n')
        run('INSERT INTO admins(username,password_hash) VALUES(?,?)', (u, generate_password_hash(p)))
    elif p and not check_password_hash(row['password_hash'], p):
        run('UPDATE admins SET password_hash=? WHERE id=?', (generate_password_hash(p), row['id']))

# ---------- theme / branding ----------
FONTS = ('grotesk', 'inter', 'mono', 'serif')
T = {'primary': ('#6366f1', 'c'), 'secondary': ('#3b82f6', 'c'), 'success': ('#22c55e', 'c'), 'danger': ('#ef4444', 'c'),
     'warning': ('#f59e0b', 'c'), 'bg': ('#050507', 'c'), 'card': ('#111114', 'c'), 'border': ('#2a2a33', 'c'),
     'text': ('#f5f5f7', 'c'), 'muted': ('#9a9aa8', 'c'), 'glow': (1, 'n', 0, 2), 'radius': (24, 'n', 0, 40),
     'blur': (14, 'n', 0, 40), 'shadow': (1, 'n', 0, 2), 'grid': (1, 'n', 0, 1), 'anim': (1, 'n', .2, 3),
     'button': ('gradient', 'e', ('solid', 'gradient', 'outline')), 'font': ('grotesk', 'e', FONTS),
     'h_size': (48, 'n', 28, 72), 'b_size': (16, 'n', 13, 20), 'width': (1200, 'n', 900, 1600)}
BRAND = {'name': 'VantixShop', 'logo': '', 'favicon': '', 'title': 'VantixShop Status', 'subtitle': 'Infrastructure Monitoring',
         'tagline': 'Monitor Everything. Stay Online.', 'hero_heading': 'Server Monitoring Made Simple',
         'hero_desc': 'Real-time monitoring and uptime tracking for your infrastructure. Get instant status updates and comprehensive system insights from one dashboard.',
         'footer': '© 2026 VantixShop. All rights reserved.', 'credit': 'Powered by VantixShop Monitoring'}

def kv(table, defaults):
    d = dict(defaults)
    for r in run(f'SELECT key,value FROM {table}', (), 'all'):
        try: d[r['key']] = json.loads(r['value'])
        except Exception: pass
    return d

def kv_set(table, d):
    c = db()
    try:
        for k, v in d.items(): c.execute(f'INSERT INTO {table}(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (k, json.dumps(v)))
        c.commit()
    finally: c.close()

def clean_theme(d):
    o = {}
    for k, v in (d or {}).items():
        if k not in T: continue
        s = T[k]
        if s[1] == 'c':
            if not re.fullmatch(r'#[0-9a-fA-F]{6}', str(v)): raise ValueError(f'Invalid color for {k}')
            o[k] = str(v).lower()
        elif s[1] == 'n':
            try: x = float(v)
            except (TypeError, ValueError): raise ValueError(f'Invalid number for {k}')
            o[k] = min(max(x, s[2]), s[3])
        else:
            if v not in s[2]: raise ValueError(f'Invalid option for {k}')
            o[k] = v
    return o

# ---------- rate limiting / auth ----------
def rl(bucket, limit):
    ip = request.remote_addr or '?'; w = int(time.time() // 60)  # never trusts client-supplied headers/params
    run('INSERT INTO rate_limits(ip,bucket,window,count) VALUES(?,?,?,1) ON CONFLICT(ip,bucket,window) DO UPDATE SET count=count+1', (ip, bucket, w))
    return run('SELECT count FROM rate_limits WHERE ip=? AND bucket=? AND window=?', (ip, bucket, w), 'one')['count'] > limit

@app.before_request
def guard():
    p = request.path
    if not p.startswith('/api/'): return
    b, l = ('login', 5) if p == '/api/login' else ('admin', 120) if p.startswith('/api/admin') else ('public', 60)
    if rl(b, l): return jsonify(error='Too many requests. Please try again shortly.'), 429

def adm(fn):
    @wraps(fn)
    def w(*a, **k):
        if not session.get('admin'): return jsonify(error='Authentication required'), 401
        if request.method != 'GET' and not secrets.compare_digest(request.headers.get('X-CSRF-Token', ''), session.get('csrf', '!')):
            return jsonify(error='Invalid CSRF token. Reload the page.'), 403
        return fn(*a, **k)
    return w

def audit(action, detail=''):
    run('INSERT INTO audit_logs(action,admin,ip,detail) VALUES(?,?,?,?)', (action, session.get('admin', '-'), request.remote_addr, str(detail)[:300]))

# ---------- monitoring ----------
def valid_url(u):
    p = urlparse(u or ''); return p.scheme in ('http', 'https') and bool(p.netloc)

def check_http(url, timeout):
    if not valid_url(url): return 'offline', None, None, 'Invalid URL'
    t = time.time(); code = None
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'VantixStatus/1.0'}), timeout=timeout) as r: code = r.status
    except urllib.error.HTTPError as e: code = e.code
    except Exception as e: return 'offline', None, None, (str(getattr(e, 'reason', e)) or 'Connection failed')[:200]
    ms = int((time.time() - t) * 1000)
    st = 'online' if code < 400 else 'degraded' if code < 500 else 'offline'
    err = f'HTTP {code}' if st != 'online' else None
    if st == 'online' and ms > SLOW_MS: st, err = 'degraded', f'Slow response ({ms}ms)'
    return st, code, ms, err

def check_tcp(host, port, timeout):
    t = time.time()
    try:
        with socket.create_connection((host, int(port)), timeout=timeout): pass
    except Exception as e: return 'offline', None, None, str(e)[:200] or 'Connection failed'
    ms = int((time.time() - t) * 1000)
    return ('degraded', None, ms, f'Slow response ({ms}ms)') if ms > SLOW_MS else ('online', None, ms, None)

def track(kind, i, name, st, ts, err):
    o = run("SELECT id FROM incidents WHERE target_type=? AND target_id=? AND status='open'", (kind, i), 'one')
    if st == 'online':
        if o: run("UPDATE incidents SET status='resolved', resolved=? WHERE id=?", (ts, o['id']))
    elif st in ('offline', 'degraded'):
        if o: run('UPDATE incidents SET severity=?, error=? WHERE id=?', (st, err, o['id']))
        else: run("INSERT INTO incidents(target_type,target_id,name,severity,status,started,detected,error) VALUES(?,?,?,?,'open',?,?,?)", (kind, i, name, st, ts, ts, err))

def run_check(kind, i):
    tbl = kind + 's'; r = run(f'SELECT * FROM {tbl} WHERE id=?', (i,), 'one')
    if not r: return None
    try:
        st, code, ms, err = check_http(r['url'], r['timeout_s']) if kind == 'service' else \
            check_http(r['host'], r['timeout_s']) if r['type'] == 'http' else check_tcp(r['host'], r['port'], r['timeout_s'])
    except Exception: st, code, ms, err = 'offline', None, None, 'Check failed'
    ts = int(time.time())
    run('INSERT INTO monitoring_logs(target_type,target_id,ts,status,http_status,latency,error_message) VALUES(?,?,?,?,?,?,?)', (kind, i, ts, st, code, ms, err))
    run(f'UPDATE {tbl} SET status=?,latency=?,http_status=?,last_check=?,last_error=? WHERE id=?', (st, ms, code, ts, err, i))
    track(kind, i, r['name'], st, ts, err)
    return st

inflight, lock = set(), threading.Lock()
def safe_check(kind, i):
    with lock:
        if (kind, i) in inflight: return
        inflight.add((kind, i))
    try: run_check(kind, i)
    except Exception as e: print('[monitor] error', kind, i, e)
    finally:
        with lock: inflight.discard((kind, i))

def worker():
    pool = ThreadPoolExecutor(8); last_clean = 0
    while True:
        try:
            t = int(time.time())
            for kind in ('service', 'server'):
                for r in run(f'SELECT id FROM {kind}s WHERE enabled=1 AND (last_check IS NULL OR ? - last_check >= interval_s)', (t,), 'all'):
                    pool.submit(safe_check, kind, r['id'])
            if t - last_clean > 3600:
                last_clean = t
                run('DELETE FROM monitoring_logs WHERE ts<?', (t - 35 * 86400,))
                run('DELETE FROM rate_limits WHERE window<?', (t // 60 - 10,))
        except Exception as e: print('[monitor] loop error', e)
        time.sleep(5)

# ---------- status data ----------
def pct(ok, n): return round((ok or 0) * 100 / n, 2) if n else None

def uptime_map(kind):
    t = int(time.time())
    q = """SELECT target_id id, COUNT(*) n, SUM(status!='offline') ok, SUM(ts>=:a) n1, SUM(ts>=:a AND status!='offline') ok1,
      SUM(ts>=:b) n7, SUM(ts>=:b AND status!='offline') ok7, SUM(ts>=:c) n30, SUM(ts>=:c AND status!='offline') ok30
      FROM monitoring_logs WHERE target_type=:k GROUP BY target_id"""
    return {r['id']: {'h24': pct(r['ok1'], r['n1']), 'd7': pct(r['ok7'], r['n7']), 'd30': pct(r['ok30'], r['n30']), 'all': pct(r['ok'], r['n'])}
            for r in run(q, {'a': t - 86400, 'b': t - 7 * 86400, 'c': t - 30 * 86400, 'k': kind}, 'all')}

def items(kind, admin):
    um = uptime_map(kind); out = []
    for r in run(f"SELECT * FROM {kind}s {'' if admin else 'WHERE enabled=1'} ORDER BY id", (), 'all'):
        d = dict(r); d['uptime'] = um.get(r['id'], {})
        if not r['enabled']: d['status'] = 'maintenance'
        if not admin:
            for k in ('last_error', 'host', 'port', 'description'): d.pop(k, None)
        out.append(d)
    return out

@app.get('/api/status')
def status():
    admin = bool(session.get('admin'))
    sv, sc = items('server', admin), items('service', admin)
    act = [x for x in sv + sc if x['enabled']]
    chk = [x for x in act if x['status'] != 'unknown']
    off = sum(x['status'] == 'offline' for x in chk); deg = sum(x['status'] == 'degraded' for x in chk)
    overall = 'unknown' if not chk else 'major' if off and off * 2 >= len(chk) else 'degraded' if off or deg else 'operational'
    lat = [x['latency'] for x in act if x['latency'] is not None]
    u24 = [x['uptime']['h24'] for x in act if x['uptime'].get('h24') is not None]
    summ = {'servers': len(sv), 'servers_online': sum(x['status'] == 'online' for x in sv), 'services': len(sc),
            'services_healthy': sum(x['status'] == 'online' for x in sc), 'overall': overall, 'failed': off,
            'avg_latency': round(sum(lat) / len(lat)) if lat else None,
            'availability': round(sum(u24) / len(u24), 2) if u24 else None, 'last_updated': int(time.time()),
            'open_incidents': run("SELECT COUNT(*) c FROM incidents WHERE status='open'", (), 'one')['c']}
    inc = [dict(r) for r in run('SELECT * FROM incidents ORDER BY started DESC LIMIT 30', (), 'all')]
    if not admin:
        for i in inc: i.pop('error', None)
    return jsonify(summary=summ, servers=sv, services=sc, incidents=inc, branding=kv('branding_settings', BRAND), theme=kv('theme_settings', {k: v[0] for k, v in T.items()}))

# ---------- auth ----------
@app.get('/')
def index(): return render_template('index.html')

@app.get('/api/session')
def sess(): return jsonify(admin=bool(session.get('admin')), csrf=session.get('csrf', ''))

@app.post('/api/login')
def login():
    d = request.get_json(silent=True) or {}
    r = run('SELECT * FROM admins WHERE username=?', (str(d.get('username', ''))[:100],), 'one')
    if not r or not check_password_hash(r['password_hash'], str(d.get('password', ''))):
        return jsonify(error='Invalid username or password'), 401
    session.clear(); session['admin'] = r['username']; session['csrf'] = secrets.token_hex(16); audit('Admin login')
    return jsonify(admin=True, csrf=session['csrf'])

@app.post('/api/logout')
@adm
def logout(): audit('Admin logout'); session.clear(); return jsonify(ok=True)

# ---------- admin CRUD ----------
def ci(v, lo, hi, dflt):
    try: return min(max(int(v), lo), hi)
    except (TypeError, ValueError): return dflt

def clean(kind, d):
    o = {'name': str(d.get('name', '')).strip()[:100], 'location': str(d.get('location', ''))[:100],
         'interval_s': ci(d.get('interval_s'), 15, 86400, 60), 'timeout_s': ci(d.get('timeout_s'), 1, 60, 10), 'enabled': 1 if d.get('enabled', 1) else 0}
    if not o['name']: raise ValueError('Name is required')
    if kind == 'service':
        o['url'] = str(d.get('url', '')).strip()[:500]; o['type'] = str(d.get('type', 'http'))[:20]
        if not valid_url(o['url']): raise ValueError('Enter a valid http(s) URL')
    else:
        o['host'] = str(d.get('host', '')).strip()[:255]; o['port'] = ci(d.get('port'), 1, 65535, 80)
        o['type'] = 'http' if d.get('type') == 'http' else 'tcp'; o['description'] = str(d.get('description', ''))[:300]
        if not o['host']: raise ValueError('Host is required')
        if o['type'] == 'http' and not valid_url(o['host']): raise ValueError('HTTP monitoring needs a full URL as host')
    return o

def kind_of(k): return {'services': 'service', 'servers': 'server'}.get(k)

@app.post('/api/admin/<k>')
@adm
def create(k):
    kind = kind_of(k)
    if not kind: return jsonify(error='Not found'), 404
    try: o = clean(kind, request.get_json(silent=True) or {})
    except ValueError as e: return jsonify(error=str(e)), 400
    i = run(f"INSERT INTO {k}({','.join(o)}) VALUES({','.join('?' * len(o))})", tuple(o.values()))
    audit(f'{kind.title()} created', o['name']); threading.Thread(target=safe_check, args=(kind, i), daemon=True).start()
    return jsonify(id=i), 201

@app.put('/api/admin/<k>/<int:i>')
@adm
def update(k, i):
    kind = kind_of(k)
    if not kind: return jsonify(error='Not found'), 404
    cur = run(f'SELECT * FROM {k} WHERE id=?', (i,), 'one')
    if not cur: return jsonify(error='Not found'), 404
    try: o = clean(kind, {**dict(cur), **(request.get_json(silent=True) or {})})
    except ValueError as e: return jsonify(error=str(e)), 400
    run(f"UPDATE {k} SET {','.join(c + '=?' for c in o)} WHERE id=?", (*o.values(), i)); audit(f'{kind.title()} edited', o['name'])
    return jsonify(ok=True)

@app.delete('/api/admin/<k>/<int:i>')
@adm
def delete(k, i):
    kind = kind_of(k)
    if not kind: return jsonify(error='Not found'), 404
    run(f'DELETE FROM {k} WHERE id=?', (i,)); run('DELETE FROM monitoring_logs WHERE target_type=? AND target_id=?', (kind, i))
    run('DELETE FROM incidents WHERE target_type=? AND target_id=?', (kind, i)); audit(f'{kind.title()} deleted', i)
    return jsonify(ok=True)

@app.post('/api/admin/<k>/<int:i>/check')
@adm
def check_now(k, i):
    kind = kind_of(k)
    if not kind: return jsonify(error='Not found'), 404
    safe_check(kind, i); return jsonify(ok=True)

@app.get('/api/admin/<k>/<int:i>/history')
@adm
def history(k, i):
    kind = kind_of(k)
    if not kind: return jsonify(error='Not found'), 404
    return jsonify(logs=[dict(r) for r in run('SELECT ts,status,http_status,latency,error_message FROM monitoring_logs WHERE target_type=? AND target_id=? ORDER BY ts DESC LIMIT 50', (kind, i), 'all')])

@app.post('/api/admin/test')
@adm
def test():
    d = request.get_json(silent=True) or {}
    st, code, ms, err = check_http(str(d.get('url', '')), ci(d.get('timeout_s'), 1, 30, 10))
    return jsonify(status=st, http_status=code, latency=ms, error=err)

@app.post('/api/admin/incidents/<int:i>/resolve')
@adm
def resolve(i):
    run("UPDATE incidents SET status='resolved', resolved=? WHERE id=? AND status='open'", (int(time.time()), i)); audit('Incident manually updated', i)
    return jsonify(ok=True)

@app.get('/api/admin/analytics')
@adm
def analytics():
    out, t = [], int(time.time())
    for kind in ('service', 'server'):
        for r in run(f'SELECT id,name FROM {kind}s ORDER BY id', (), 'all'):
            s = run("SELECT COUNT(*) n, AVG(latency) a, MIN(latency) lo, MAX(latency) hi, SUM(status='offline') f FROM monitoring_logs WHERE target_type=? AND target_id=? AND ts>=?", (kind, r['id'], t - 86400), 'one')
            pts = [x['latency'] for x in run('SELECT latency FROM monitoring_logs WHERE target_type=? AND target_id=? AND latency IS NOT NULL ORDER BY ts DESC LIMIT 60', (kind, r['id']), 'all')][::-1]
            dt = run("SELECT COALESCE(SUM(COALESCE(resolved,?)-started),0) d, COUNT(*) c FROM incidents WHERE target_type=? AND target_id=? AND started>=?", (t, kind, r['id'], t - 86400), 'one')
            out.append({'name': r['name'], 'type': kind, 'checks': s['n'], 'avg': round(s['a']) if s['a'] is not None else None, 'min': s['lo'], 'max': s['hi'],
                        'fails': s['f'] or 0, 'points': pts, 'downtime_s': dt['d'], 'incidents': dt['c']})
    return jsonify(items=out)

@app.get('/api/admin/audit')
@adm
def audit_list(): return jsonify(logs=[dict(r) for r in run('SELECT action,admin,ip,detail,ts FROM audit_logs ORDER BY id DESC LIMIT 100', (), 'all')])

@app.put('/api/admin/theme')
@adm
def theme_save():
    try: o = clean_theme(request.get_json(silent=True))
    except ValueError as e: return jsonify(error=str(e)), 400
    kv_set('theme_settings', o); audit('Theme changed'); return jsonify(ok=True)

@app.post('/api/admin/theme/reset')
@adm
def theme_reset(): run('DELETE FROM theme_settings'); audit('Theme reset'); return jsonify(ok=True)

@app.put('/api/admin/branding')
@adm
def brand_save():
    d = request.get_json(silent=True) or {}
    o = {k: str(v)[:600] for k, v in d.items() if k in BRAND}
    for k in ('logo', 'favicon'):
        if o.get(k) and not (o[k].startswith(('https://', 'http://', '/static/', 'data:image/'))): return jsonify(error=f'{k} must be an http(s) URL'), 400
    kv_set('branding_settings', o); audit('Brand changed'); return jsonify(ok=True)

@app.errorhandler(404)
def nf(e): return (jsonify(error='Not found'), 404) if request.path.startswith('/api/') else render_template('index.html')

@app.errorhandler(Exception)
def err(e):
    code = getattr(e, 'code', 500)
    if code == 500: print('[error]', repr(e))
    return jsonify(error='Something went wrong. Please try again.' if code == 500 else getattr(e, 'description', 'Error')), code

init_db()
if __name__ == '__main__':
    threading.Thread(target=worker, daemon=True).start()
    app.run(host=os.environ.get('HOST', '127.0.0.1'), port=int(os.environ.get('PORT', 5000)), debug=False, threaded=True)
